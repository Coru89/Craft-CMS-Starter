-- MariaDB dump 10.19  Distrib 10.5.15-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.4.26-MariaDB-1:10.4.26+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_slpkeqxvnfoybhdreggbzdivkjcxwjcyftie` (`ownerId`),
  CONSTRAINT `fk_gldqpezcnetooncizpmdmgldakaswjlookbc` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_slpkeqxvnfoybhdreggbzdivkjcxwjcyftie` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `pluginId` int(11) DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT 1,
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dhedjktejbinajvphfuamjefochdyreodphx` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_qgkspwxvcrbbloostqnxxtpkcqtzlctrprcz` (`dateRead`),
  KEY `fk_wmqxudqwtzbqbopvcttfnuxkhugmcnwhntil` (`pluginId`),
  CONSTRAINT `fk_iuyytyvfangwgvlvdezxnolnbrrhylhjpmts` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wmqxudqwtzbqbopvcttfnuxkhugmcnwhntil` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` int(11) NOT NULL,
  `volumeId` int(11) NOT NULL,
  `uri` text DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT 0,
  `recordId` int(11) DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT 0,
  `inProgress` tinyint(1) DEFAULT 0,
  `completed` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_poaqqzcehpqtjmqsufetnvgeeykpebggnkwu` (`sessionId`,`volumeId`),
  KEY `idx_hzdzkkphrllqcvndbnzwjbcngetpqcrcwzft` (`volumeId`),
  CONSTRAINT `fk_fwkkouozkocivettdouhnrmksfhafwbdtrav` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qrnjqfztiwoblyzsgwotddlvpwfyfnduggrq` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text DEFAULT NULL,
  `totalEntries` int(11) DEFAULT NULL,
  `processedEntries` int(11) NOT NULL DEFAULT 0,
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT 0,
  `isCli` tinyint(1) DEFAULT 0,
  `actionRequired` tinyint(1) DEFAULT 0,
  `processIfRootEmpty` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fdxjvtwzubkzybnrhxcggvzydmcwmpeizgtt` (`filename`,`folderId`),
  KEY `idx_qqbmvnwyogduyynsjblzvuzrgptjqnmolkox` (`folderId`),
  KEY `idx_fecdeiylwghgfbvycjxzftbgnqkbuwyxfacd` (`volumeId`),
  KEY `fk_tkldqexmrhdklaywezessowavtstjghdkwkc` (`uploaderId`),
  CONSTRAINT `fk_fzrzrqwgtplbhrwgnivwucqlnbluvzdpdieh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qxavyopsifroyieafhhzrvfoomnabuwxoemx` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rkmeyngytypauvqvpexnnjtkctfnpgllwgkf` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tkldqexmrhdklaywezessowavtstjghdkwkc` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_oxbpajnzubrbenxqauondffvjbfvlaxjvlei` (`groupId`),
  KEY `fk_buwhsnwmxukicoyflhmkrkqtskprssbbzliv` (`parentId`),
  CONSTRAINT `fk_buwhsnwmxukicoyflhmkrkqtskprssbbzliv` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jgsswikjegrwdpxcjjfcitfzvvwlylfnclgv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rydmlbmtqyvaxivzhzghfikyxoodpqhglslj` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kkaypfirvsmxngazoaqpknpdzckmrcncdxpp` (`name`),
  KEY `idx_pjzuegslgtgiixqslxgtfazdmiokkiipccqk` (`handle`),
  KEY `idx_ofzkfgmqximcijvypmhodeunojngwrxgckyl` (`structureId`),
  KEY `idx_tfpppzrdrjntmdagpcpuxkditmmtyvmxpftw` (`fieldLayoutId`),
  KEY `idx_spipfwwhitobewrzvlrrbbxjgzdlcpknjvqb` (`dateDeleted`),
  CONSTRAINT `fk_lznjtsbeuxtyozudtukbwrhgytbeowsvmdns` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zaosbskyxveqhigfgxozqgsacbixowvtbwxy` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lrjbwxzhzufpbpyghpucswzelnhxdwbrrvga` (`groupId`,`siteId`),
  KEY `idx_qjwkokrogemclvninuzboqbbyatdaqkdpahm` (`siteId`),
  CONSTRAINT `fk_ggqescmjhvvttqmzmrilgtyogvouyhmfbzla` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wgelssrucipkuhkmxrpardikblmekjakowce` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_cyhirdixwictldpbwxtokywbmbrhbfkqpqhc` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_qebgvfyxcvuzkdzqkahjxweuufuenhxblqfz` (`siteId`),
  KEY `fk_cnuqvcnwxrnobeovsglggxloyaqcnlnrlxst` (`userId`),
  CONSTRAINT `fk_cnuqvcnwxrnobeovsglggxloyaqcnlnrlxst` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_crorkiplgoxdjbbdbjzwgqdostitggspejvy` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qebgvfyxcvuzkdzqkahjxweuufuenhxblqfz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_llqknxpmmzxjfvkyekhiysxlgntykflegytr` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_uslpfwukiuincwukzydgdvbmiwhpsvgldipl` (`siteId`),
  KEY `fk_xsqyojvotstckoemjaipuldvooyiqfyzdzzj` (`fieldId`),
  KEY `fk_jaclwsbznpqypgnxflktzyczxopowjfpinff` (`userId`),
  CONSTRAINT `fk_jaclwsbznpqypgnxflktzyczxopowjfpinff` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_oofuqmuesmubkzmwxbfjjxqaxmcenmbnbsqj` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uslpfwukiuincwukzydgdvbmiwhpsvgldipl` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xsqyojvotstckoemjaipuldvooyiqfyzdzzj` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_navigationItems_bkoedaxb` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hsrejroefkehvqonndmfdseqcasyzgzzqlro` (`elementId`,`siteId`),
  KEY `idx_zytkzufdsysjdjcpvkshlmgahdofuurajbkl` (`siteId`),
  KEY `idx_mkkhrfgrpkiiawmyfpzcophaivncgwqvxfod` (`title`),
  CONSTRAINT `fk_eajteuvluadjqzslvmmhulrmelhlanyaadvv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ymzdxnuqumzhnefetabgxujzfiptmhcmpdpf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_znlbicetlbvbmbctmufvjyivuatvjrfmtqyu` (`userId`),
  CONSTRAINT `fk_znlbicetlbvbmbctmufvjyivuatvjrfmtqyu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text DEFAULT NULL,
  `traces` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_isjsltphefdgblfswejskkbjzlcyddawqbxg` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `trackChanges` tinyint(1) NOT NULL DEFAULT 0,
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_mrcgbpcealvsxouipftekanvhuyhvrapbmnt` (`creatorId`,`provisional`),
  KEY `idx_ltunxxqbaolskomomnrknscfomfczyjzhaqs` (`saved`),
  KEY `fk_nmgjqvndlkleoipuhpbpvemrdklhezptrmga` (`canonicalId`),
  CONSTRAINT `fk_dknnousuqigvucewnyxkyrndmaafuztoesyu` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_nmgjqvndlkleoipuhpbpvemrdklhezptrmga` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pzvewufsxijxyqgetbjvdaofnvctnukfqzqj` (`dateDeleted`),
  KEY `idx_cjkqdbmhvrbjgodxekebvdjpuxytkkfjrzlx` (`fieldLayoutId`),
  KEY `idx_lfudwdgdzliksqitksahreqvorbxwpvciedq` (`type`),
  KEY `idx_fxatcvfjllamevzquywfjjimtqgammdfglpw` (`enabled`),
  KEY `idx_uszuujqoxcdcvjsmvxxbmipgotpufhpisshc` (`canonicalId`),
  KEY `idx_kgpvfwkpfzbtbftiacwqfqtupbltkijjxczf` (`archived`,`dateCreated`),
  KEY `idx_tukaakenfnoxpjromzrrovkvbhzhfgjdkdwm` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_mlsozurtffmaxcjdyvxfstnekttigrereeuq` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_mmqylheebdleonwwvhlsvuvckctukcyfjhht` (`draftId`),
  KEY `fk_oomlwjwkcodugtubzveqmassaslbmcovbijn` (`revisionId`),
  CONSTRAINT `fk_mmqylheebdleonwwvhlsvuvckctukcyfjhht` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oomlwjwkcodugtubzveqmassaslbmcovbijn` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pvrhuidwktbebaisfztyjxcsiehvghcgjgrm` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ysmobcjtiebrxhgbhnnajtsjuctprawkkuyl` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zhlekrwosoxrhmnskoxskicvbrhicfbjgumo` (`elementId`,`siteId`),
  KEY `idx_eionbebkviezykpravynscxfxjzzcoudssjv` (`siteId`),
  KEY `idx_egkoikwcvybkyjubuahdjnglaqhsdxvdbdmb` (`slug`,`siteId`),
  KEY `idx_fduolqcpkxkhikfjgrnutaegfontavlocprh` (`enabled`),
  KEY `idx_zturxobupsneedxqtyhmohzwnsyywoqsgahq` (`uri`,`siteId`),
  CONSTRAINT `fk_niiwhunmocgbyofxpmmwilrlrstyixestino` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_oxkahxkudfsfggilmomggqjbjwlgbjgvmnkc` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jrmrtskdvimffqdgjvumslbliwjpvtlqlwhs` (`postDate`),
  KEY `idx_wibsicypzwkwzzheeilcxbslbnvwltshekot` (`expiryDate`),
  KEY `idx_pudbovfidvqalpqqgmswmekldvxlpmxjdpwl` (`authorId`),
  KEY `idx_ctzbgixvfryfmpwjfosvwtyrwtvjtafrcxfa` (`sectionId`),
  KEY `idx_jcvgzhctgwsvhgyyjpdysedcjqmjduvqqihe` (`typeId`),
  KEY `fk_uonbycaakdldttjopmlfqtgrgfsdnmxwtyyf` (`parentId`),
  CONSTRAINT `fk_bqzfbabxndyttyiveicsnfipjokgxvhqkvea` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_idndnzcupmabrgvkemxpahisgfvvfnaxepml` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uonbycaakdldttjopmlfqtgrgfsdnmxwtyyf` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wscqgcmbizufdfbssagzutgvgczcahvresec` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yndwsubcuuwffipfdkrecjhszvfyuczrbesl` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fhxaijwuavfdjebohbicwnytxvwuhsbchzif` (`name`,`sectionId`),
  KEY `idx_kqewvspksbsgfvumopfysxoxzyxxlyxceueo` (`handle`,`sectionId`),
  KEY `idx_yfzxzusyslojxeadfkbejfxztvhmvucunikh` (`sectionId`),
  KEY `idx_gyryxjwbxtpbbtolcqzramsmudaffaefngrh` (`fieldLayoutId`),
  KEY `idx_asrufuoktmkjdxhsfuaexqjqngfpekrgeidd` (`dateDeleted`),
  CONSTRAINT `fk_fpphhxpedjaaowntnthzjstehzmvaaesufoq` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ysufshdjbeqhddvgoulqrxhrervgpzyegzcn` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uqpblpvllqfuevrqdgbmzgdhxjjdeysxsnpb` (`name`),
  KEY `idx_vplvycvovicvioxvrxadhzsiubaistdeehof` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cpokamsnxhkxkjgasxmhetzbuvxqaecfymuj` (`layoutId`,`fieldId`),
  KEY `idx_qgwfocvcqxkhhlugychzymcmnpxygcywcwjd` (`sortOrder`),
  KEY `idx_moqaxnbvejjcqvbfqeabqmnpymnwiyuaxwiz` (`tabId`),
  KEY `idx_fjsvuniirnmkzzvhekuqyjgjhwovkktfxxaq` (`fieldId`),
  CONSTRAINT `fk_aigksysamcwkozsohlulmnojznwcvnbozgbv` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dxqicafffpcrvugzxmtcohizarkeibrcmjte` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nvexpokmdylzhomwjxmwjqaiktpjkctbmflb` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cotxxkyfzodimkiqrvnoxxnafrahapbatdgj` (`dateDeleted`),
  KEY `idx_hagvxsywjpazsrzivzjyxlrbsoxhkosznmkl` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `elements` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xzjdnoawnnnhvxynayygjlrvdcxkbgekujrf` (`sortOrder`),
  KEY `idx_aabzlunvtuiiecuzygdihmneheokcvxfpbzu` (`layoutId`),
  CONSTRAINT `fk_bjrcgkpfwrznovuglprgrhkcmuchmtehgaot` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `searchable` tinyint(1) NOT NULL DEFAULT 1,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kwfkzfawlkzonstawbyvdwvvcgszvwzzowzc` (`handle`,`context`),
  KEY `idx_ljuxrctylwuzffffcllenwevxzoharpzwual` (`groupId`),
  KEY `idx_rimzcbmmlbnfnqbeasasmtvjljpucnwjnfsf` (`context`),
  CONSTRAINT `fk_vneucqcsqiatnndqxwomojaguikljmyodxjv` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_plwthdjvndblhujcepxhamjnhlhgogvpmmqy` (`name`),
  KEY `idx_jvifvnapnieafujdasvevglzrgizdrfmkknu` (`handle`),
  KEY `idx_asrvewyylovyaqlsmgetfxupyhbtsberhixx` (`fieldLayoutId`),
  KEY `idx_mjcbyamuydguqclslplzqglfsfiopulalvrr` (`sortOrder`),
  CONSTRAINT `fk_ftxgqjvsoxqjfndhbcowbrutgrstohwubirm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nuwshmociqjpprbbrsppyzejsmrqbhjlmpva` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yvhhitbyfnajftcrohaugezsozrtldlblhje` (`accessToken`),
  UNIQUE KEY `idx_otmtuoasbcuplukinperhezdffyiocqtrzqp` (`name`),
  KEY `fk_nheimdyaoqasrkmmdtquiimdtgocxpiwyxuq` (`schemaId`),
  CONSTRAINT `fk_nheimdyaoqasrkmmdtquiimdtgocxpiwyxuq` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT 0,
  `inProgress` tinyint(1) NOT NULL DEFAULT 0,
  `error` tinyint(1) NOT NULL DEFAULT 0,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cykcavhrnkmbimwacexxwryrraqdwhqnrrre` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT 1,
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nyyrlzisebjuaomvrptraqygekkdfalpxaxh` (`name`),
  KEY `idx_vmvmgdnumfzlhlnmsbwwcoyosftzopiqngrx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `primaryOwnerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_bopeegzicfijnhjvrvcxsjxtupktwrfwgzrk` (`primaryOwnerId`),
  KEY `idx_dtwigkzqfistnrjuzuwytxwcclwesdjeuqsa` (`fieldId`),
  KEY `idx_rahjxokqermpxwygueoikygiryiabygmdcek` (`typeId`),
  CONSTRAINT `fk_agpexzfggfawthywvbizrgmsgfamulkxwwox` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_inwtzxfhainkgtymvxuzqlybndqahgvkiisu` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jxswvgslfuakrlhivrjaphhfqriwfoyvbelg` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pzmwcdhoqjrpisncgqtlbnrbgidwfwribvqf` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_bldkgeyevouueiyidyejbagnnpvcgvahmraj` (`ownerId`),
  CONSTRAINT `fk_bldkgeyevouueiyidyejbagnnpvcgvahmraj` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ofgidabofabntntetmmpnwxdzdyxxgdwxceu` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zjsrgvpatfenvjygynoayitjbjnwngvpnyaz` (`name`,`fieldId`),
  KEY `idx_ffkowipiyjatlyiezbejktxfrcmnxlqcyvyx` (`handle`,`fieldId`),
  KEY `idx_jluquqnpmzokoyhcljpyafbxmmlitngbnfdy` (`fieldId`),
  KEY `idx_ixycizvcuftropaxnmxvyjqreffbfipavord` (`fieldLayoutId`),
  CONSTRAINT `fk_dqcnadkeolzqtmqwolaxzexfqwkhivmwihcs` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_drqzcdgswqandloafrjcvporfuqeinfhorcd` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_contentpanels`
--

DROP TABLE IF EXISTS `matrixcontent_contentpanels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_contentpanels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_heroPanelDark_heroButtonText` text DEFAULT NULL,
  `field_heroPanelDark_subject` varchar(256) DEFAULT NULL,
  `field_heroPanelDark_panelContent` text DEFAULT NULL,
  `field_heroPanelDark_heroButtonHref` text DEFAULT NULL,
  `field_heroPanelDark_panelTitle` varchar(256) DEFAULT NULL,
  `field_contentPanel_panelSubheading` text DEFAULT NULL,
  `field_contentPanel_panelTitle` varchar(512) DEFAULT NULL,
  `field_heroPanel_subject` varchar(256) DEFAULT NULL,
  `field_heroPanel_panelTitle` varchar(1024) DEFAULT NULL,
  `field_heroPanel_panelContent` text DEFAULT NULL,
  `field_callToAction_buttonText` varchar(256) DEFAULT NULL,
  `field_callToAction_panelTitle` varchar(512) DEFAULT NULL,
  `field_callToAction_buttonHref` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vmulpwtxkbnmojvnqsgmupjdmeflcfxczzbo` (`elementId`,`siteId`),
  KEY `fk_utalvnmqepkwjntvmxyucjmrywxgnygzwetb` (`siteId`),
  CONSTRAINT `fk_fexzknbjaipcseuteabrikyrtipqkdjogtrm` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_utalvnmqepkwjntvmxyucjmrywxgnygzwetb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vlfbqiljutvrdxmhdsbrmmuixaptkcbagxpn` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mzcxogjoniptzomwvrtfjkkgruflokctbirj` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text DEFAULT NULL,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) unsigned NOT NULL DEFAULT 1024,
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT 0,
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT 0,
  `dateFailed` datetime DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ophrqeuhbwpsunavicrzhyqvvwpjkqejjyoy` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_cewideclldnzbluzfyulbnslztqhumkhusaq` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_auxxduyfkoccakpzzrkewxvckqylxtchrmbg` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_pfarkzkflrncggrebpiqgilvncwydsbawbnc` (`sourceId`),
  KEY `idx_goxfmkgwqpgfnvurxchglkvpfhjqrvbdqmky` (`targetId`),
  KEY `idx_ehjgtghuuizbvdrlmmdjiifmygpwrpuajyjr` (`sourceSiteId`),
  CONSTRAINT `fk_cbpybsqlrmxliyilckfwgjskyzrdznlkgnbj` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fydqhkbpgkhgrrtikmjkalwjsbxaftckjvsm` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zonyspqvytgynjfhvgynnwdnxakxzysskhci` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xcmttjxczqopkqnjzgdjmgtxawljbbufaiaz` (`canonicalId`,`num`),
  KEY `fk_syrmjjthfhaaogxmtsintanvoqhfkxfqxvam` (`creatorId`),
  CONSTRAINT `fk_pdspnpzxcoqtuezudvfhfdxmmlshbsjnhcuq` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_syrmjjthfhaaogxmtsintanvoqhfkxfqxvam` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_ekcoxwtkuluggutvobxfvvxsloynwxvhkoso` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT 0,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qcfsscgglypesofhshllodfkvwlqazkvikvg` (`handle`),
  KEY `idx_hdgnavbagzgvukoywijjrytqgbaueskblpuy` (`name`),
  KEY `idx_gaeyxstllxbbfgkhvilxwjmqkuiozupelpqs` (`structureId`),
  KEY `idx_yttsuguhlostjsovotmpkghkhlrtpfotqgbl` (`dateDeleted`),
  CONSTRAINT `fk_tdwwmymcvjhetlvlfgjrveuutpxfoustlxwf` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_seivgzvziyhsdiwrmyoebtskjykvykiezvsj` (`sectionId`,`siteId`),
  KEY `idx_dqdqiwdqagiojkwubgbenivlzmnfnylhxjlp` (`siteId`),
  CONSTRAINT `fk_myqqnkbjfefmiwdiaarcforzkioasmlaehpp` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_twtdsrrteqntrmfmlfdprjymjmkhkguuzvvb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `seo_redirects`
--

DROP TABLE IF EXISTS `seo_redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seo_redirects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `type` enum('301','302') NOT NULL,
  `siteId` int(11) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `seo_sitemap`
--

DROP TABLE IF EXISTS `seo_sitemap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seo_sitemap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` enum('sections','categories','productTypes','customUrls') NOT NULL,
  `url` varchar(255) NOT NULL,
  `frequency` enum('always','hourly','daily','weekly','monthly','yearly','never') NOT NULL,
  `priority` float NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xfcwbetoqbnmyiqgljpgfhngavsabyctulyu` (`uid`),
  KEY `idx_cibiuzobikusbyydkgobyermdcyaktgjlefj` (`token`),
  KEY `idx_hqnkaunsusjdwcqwrjurhchuknunjijehvcn` (`dateUpdated`),
  KEY `idx_vplfidcesgobhykufnxlzpnpjzpnjtpotqlx` (`userId`),
  CONSTRAINT `fk_mjuuszwmtcauebsdaayjlvygquaprsvpkbpy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_oisskogyxjebiwmvtemdvupbpguybbsqftrh` (`userId`,`message`),
  CONSTRAINT `fk_zvczrecogrncuubxpkilvhuqyxioasobzydw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_stoizgqpmarrxnymgsnkcxpvilycfxkbzjgm` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 0,
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vmiaexjehtosnilbylxhuqcywjxugrffdosv` (`dateDeleted`),
  KEY `idx_cfxnquhjyqmxdnmyfpsqflgztroomalljqfx` (`handle`),
  KEY `idx_pbponsdcijfuggjccjvgdiacttgyktdddfat` (`sortOrder`),
  KEY `fk_sjtavmftrefmofwlndnqnkifyjndglvrkjki` (`groupId`),
  CONSTRAINT `fk_sjtavmftrefmofwlndnqnkifyjndglvrkjki` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_warfxgpivutrviczlzbvpsjojoybnsvnekuc` (`structureId`,`elementId`),
  KEY `idx_yirtnxaxqzrvmfalvbvtxrulrisgsphfimtn` (`root`),
  KEY `idx_iqsrxofonldpwpitzhbfslofapmsflpayazm` (`lft`),
  KEY `idx_fwtxwvjoshaeanizixxnesnakidhsxrzsgpt` (`rgt`),
  KEY `idx_bxwpmksyvdqwldkpakgwgyjfaubkelbprddb` (`level`),
  KEY `idx_mkeoazqtlevyfwzwafogahfurgvgxnbvqozm` (`elementId`),
  CONSTRAINT `fk_zhaxpinwiyyiuuehfawxwvwwmezkrxskjnii` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iusvqlckdvxpegzdhltvgxpzrbczbpotqtns` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hzkeadywnavquguebhrihdqalajqzkokqegy` (`key`,`language`),
  KEY `idx_kfcojkglhlpsjosmypyapvsmwfuuotexpvbi` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_poswnidnribnphfwdzknxxcqcdtxzgsvhzsn` (`name`),
  KEY `idx_mpjihfjobztnyqacwvmpcojstgtjuenlhsvw` (`handle`),
  KEY `idx_krmytfmyvtakhoxhsrchgctzdmajbbihtjuv` (`dateDeleted`),
  KEY `fk_wpulybekkwtrmkgknoxpvxxzsbzxhjrrvibt` (`fieldLayoutId`),
  CONSTRAINT `fk_wpulybekkwtrmkgknoxpvxxzsbzxhjrrvibt` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_yetottzryermdiwybxgyhrgbixtigehftodj` (`groupId`),
  CONSTRAINT `fk_aeihqhipqtvcxhuhapdkkqzckcctwacxwobr` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gdeufkhxsyyhybvpqlcysxocvkwspuripbgt` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text DEFAULT NULL,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nakfiaxgvzhxwcpwjtqhttxvihryfjbvjurw` (`token`),
  KEY `idx_dycrfkofkoukzftgwmpblapblcztavmifcgt` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gpnectvgysnhnpoqmgpkzjvxcqejxynyesxn` (`handle`),
  KEY `idx_duxcrrdfnfxmsqahpjvfycfujyjwmzfeoaol` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ylovjjfmiuristyjlhsbfriagntregeqqyes` (`groupId`,`userId`),
  KEY `idx_qkiizpdnoluqwakbgbnoqoqvuahfhrickmzm` (`userId`),
  CONSTRAINT `fk_ayqvwsabfxafbatenbdtumrmaaxmorloljib` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gtpzaaabxmyrmknhdvbumraozlrahchzlsls` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vejnzaqouvlhpcacvrlvnuteqldeeoonpjoz` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kcjhcjheijqwhbteqcktjicqbqedeidzfcfu` (`permissionId`,`groupId`),
  KEY `idx_eemsxkkccupumwalqvszcskrgrlgvryxpfxw` (`groupId`),
  CONSTRAINT `fk_gqtvxwonxdllqahkibpqkevkkuiubcsvkznh` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yrjcdjqqyrfjhujhmgpvxmgnemlykwkhnleu` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gonkhrudvrzqtcutsjnekhxaqbrymhuryipj` (`permissionId`,`userId`),
  KEY `idx_lkstcktgygbnqelbkpijtrpaxbappypneidh` (`userId`),
  CONSTRAINT `fk_bjdpfuqbqreajjcahnxcbqpusmdyfsnhsuut` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yhjthtzzarkjitcbvlaabbcskrtyccjxacdy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_ukpmsxkvewwtkxuisytniogairfgtvjyapgy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `pending` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `suspended` tinyint(1) NOT NULL DEFAULT 0,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT 0,
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT 0,
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_nikhafwelibsfhscjowlfdgpjlcaohzstcrr` (`active`),
  KEY `idx_zqlujdznuarstfgbcjxpvliozwfruumpizbw` (`locked`),
  KEY `idx_ytmkzhzazvaezmwexvxjxesqhierswggamzr` (`pending`),
  KEY `idx_fwvfwgifbuelarcihaslbqtqqpxurhpdskdk` (`suspended`),
  KEY `idx_uvfoblnjodfaweghcycwqbgsjlducwvghzca` (`verificationCode`),
  KEY `idx_racmtwmwyfkrglsfdxhmgfkvvbumribcclve` (`email`),
  KEY `idx_jjginfpuzuuxrjcrqdwzraniurkedwmikroz` (`username`),
  KEY `fk_csfmdktzmbodqldulqwuecqytsblszxgimii` (`photoId`),
  CONSTRAINT `fk_csfmdktzmbodqldulqwuecqytsblszxgimii` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dzhfjzdjqrrdkmyguwwxiltvnwnzbqobeypo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gfmtkmenlsmuydmcvstpxiwincubhswtvmoh` (`name`,`parentId`,`volumeId`),
  KEY `idx_anarkdybhfcqrusxyflzncutnehbplwzbbnz` (`parentId`),
  KEY `idx_qxldsnrzskthdwauprkksxhxmxigdgtcfpzs` (`volumeId`),
  CONSTRAINT `fk_kvroiigerodugwwuysokisxfdludyqdmjvqa` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nooupwobfvxyamnjyytnwuuebfzqpummlowm` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_deraajzmclruzzieghrgqbrxqpgwvnrsnrlw` (`name`),
  KEY `idx_wffprunvlhlhoplcxbfmdhtxeqrybprltrka` (`handle`),
  KEY `idx_pxjnzwmaxwnqzpvsmagcdxgwuleswxojlycb` (`fieldLayoutId`),
  KEY `idx_oxzclyljdynbfqmfghibgzckltskshvdufnn` (`dateDeleted`),
  CONSTRAINT `fk_aqijedxmexpxabjxvhblelptblrqtnpilldp` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tjecakiddaihllgvphzrowoixfiwnlbpxcbq` (`userId`),
  CONSTRAINT `fk_ummcznhadzstgjiulrdvqztsiyphvbahiubz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-13 13:29:12
-- MariaDB dump 10.19  Distrib 10.5.15-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.4.26-MariaDB-1:10.4.26+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (41,NULL,3,1,'asset640ef77e8c76c2.37057844.webp','image',NULL,1200,800,3374,NULL,NULL,NULL,'2023-03-13 10:14:22','2023-03-13 10:14:22','2023-03-13 10:14:22'),(46,NULL,3,1,'placeholder.webp','image',NULL,1200,800,3374,NULL,NULL,NULL,'2023-03-13 11:15:35','2023-03-13 11:06:33','2023-03-13 11:15:35'),(47,NULL,3,1,'placeholder_2023-03-13-111531_ufkd.webp','image',NULL,1200,800,3374,NULL,0,0,'2023-03-13 11:15:31','2023-03-13 11:15:31','2023-03-13 11:15:31'),(50,1,1,1,'placeholder.webp','image',NULL,1200,800,3374,NULL,NULL,NULL,'2023-03-13 11:18:46','2023-03-13 11:18:46','2023-03-13 11:18:46');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (9,1,'uri','2023-03-13 09:17:22',0,1),(10,1,'uri','2023-03-13 09:17:22',0,1),(11,1,'uri','2023-03-13 09:17:22',0,1),(12,1,'uri','2023-03-13 09:17:22',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (2,1,2,'2023-03-13 11:20:13',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2023-03-12 17:05:10','2023-03-12 17:05:10','2875f908-e400-446b-af0d-8b29ae0e571a',NULL),(2,2,1,'Home','2023-03-13 03:54:54','2023-03-13 11:20:13','ea88ab87-46d4-4a39-adca-c05c5365c209',NULL),(3,3,1,'Home','2023-03-13 03:54:54','2023-03-13 03:54:54','1ac70718-2f60-4940-9cb9-93a4d81b41f8',NULL),(4,4,1,'Home','2023-03-13 03:54:54','2023-03-13 03:54:54','fc17e0e1-38b9-48a9-9990-987fc6ed3917',NULL),(5,5,1,'Home','2023-03-13 03:55:05','2023-03-13 03:55:05','bcf785b4-6e83-452a-aa7f-232ed10d86a7',NULL),(6,6,1,'Home','2023-03-13 04:38:29','2023-03-13 04:38:29','72e8faf1-8cb7-4ad2-9eb9-89cb86c48f4f',NULL),(7,7,1,NULL,'2023-03-13 08:37:14','2023-03-13 09:11:08','8a932f48-b273-4b0c-9ce1-db44db990769','[{\"col1\":\"About\",\"col2\":\"/about\"},{\"col1\":\"Events\",\"col2\":\"/events\"},{\"col1\":\"Contact\",\"col2\":\"/contact\"}]'),(8,8,1,NULL,'2023-03-13 08:59:53','2023-03-13 08:59:53','fe61cd9b-e26d-43d4-9db8-d0555a7eeb58','[{\"col1\":\"\",\"col2\":\"\"}]'),(9,9,1,'About','2023-03-13 09:16:41','2023-03-13 09:52:39','c1e2a0bf-b99e-4734-9361-594453f26d3a',NULL),(10,10,1,'About','2023-03-13 09:16:41','2023-03-13 09:17:22','efe8bb0e-8732-4c5e-9577-dce071b49f84',NULL),(11,11,1,'About','2023-03-13 09:16:41','2023-03-13 09:17:22','395bea4a-ae6b-4028-8c5b-c9ad60c81a53',NULL),(12,12,1,'About','2023-03-13 09:16:41','2023-03-13 09:17:22','d7a300a3-db76-45b3-ab0e-4740330a2b10',NULL),(13,13,1,'Contact','2023-03-13 09:17:00','2023-03-13 09:17:00','659d755e-2589-46fa-8217-a66cdcc68353',NULL),(14,14,1,'Contact','2023-03-13 09:17:00','2023-03-13 09:17:00','c9bb311c-23e5-4312-9944-b7fac4f37e05',NULL),(15,15,1,'Contact','2023-03-13 09:17:00','2023-03-13 09:17:00','32ce91d9-acdd-4234-89c0-8e8883dcd594',NULL),(16,16,1,'About','2023-03-13 09:17:22','2023-03-13 09:17:22','4ac4bd7e-58f6-4432-bffd-8f0699bf33b5',NULL),(17,17,1,'About','2023-03-13 09:17:22','2023-03-13 09:17:22','568c5212-1d99-45c6-96dc-c0f68e9e9090',NULL),(18,18,1,'Home','2023-03-13 09:52:24','2023-03-13 09:52:24','c095e0e5-d7e3-4c7a-8cd3-7ead9f5b4bc5',NULL),(19,19,1,'About','2023-03-13 09:52:39','2023-03-13 09:52:39','96e0f958-adff-484f-8422-3806089708cb',NULL),(23,41,1,'Placeholder','2023-03-13 10:14:22','2023-03-13 10:14:22','74d01803-185d-42a6-a2e9-72be8ba76963',NULL),(28,46,1,'Placeholder','2023-03-13 11:06:33','2023-03-13 11:15:35','7046d748-a903-4ded-8bc4-13d3462063f5',NULL),(29,47,1,'Placeholder','2023-03-13 11:15:31','2023-03-13 11:15:31','248001b2-826e-4aed-91ba-cafd68d8b3eb',NULL),(32,50,1,'Placeholder','2023-03-13 11:18:46','2023-03-13 11:18:46','428dfa88-bbfe-474c-b821-8cb9a8e723da',NULL),(33,54,1,'Home','2023-03-13 11:20:13','2023-03-13 11:20:13','15623fcf-c7bd-4430-9a94-88d57ecd484d',NULL);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2023-03-12 17:05:10','2023-03-12 17:05:10',NULL,NULL,'f19f973b-e7ed-4226-821b-cbf8056787d1'),(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-03-13 03:54:54','2023-03-13 11:20:13',NULL,NULL,'b3e5a021-8977-49cd-bb15-3989407cb22d'),(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2023-03-13 03:54:54','2023-03-13 03:54:54',NULL,NULL,'9abfd264-75a4-404d-b142-d4d974305912'),(4,2,NULL,2,1,'craft\\elements\\Entry',1,0,'2023-03-13 03:54:54','2023-03-13 03:54:54',NULL,NULL,'fe376f58-8181-4609-90e2-7beb369ca28f'),(5,2,NULL,3,1,'craft\\elements\\Entry',1,0,'2023-03-13 03:55:05','2023-03-13 03:55:05',NULL,NULL,'05f3f9e8-a524-4ffc-91eb-bfaa7bef168a'),(6,2,NULL,4,1,'craft\\elements\\Entry',1,0,'2023-03-13 04:38:29','2023-03-13 04:38:29',NULL,NULL,'8a9d3b63-ee0a-40e5-be56-27a0b00b076a'),(7,NULL,NULL,NULL,2,'craft\\elements\\GlobalSet',1,0,'2023-03-13 08:37:14','2023-03-13 09:11:08',NULL,NULL,'8321f181-1adc-441d-9199-5af52c1c14a4'),(8,NULL,NULL,NULL,2,'craft\\elements\\GlobalSet',1,0,'2023-03-13 08:59:53','2023-03-13 08:59:53',NULL,'2023-03-13 09:01:46','3a25d975-5d0c-431a-94d6-a3a578faebf1'),(9,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-03-13 09:16:41','2023-03-13 09:52:39',NULL,NULL,'03a501ef-4afb-4333-9f81-623758b62937'),(10,9,NULL,5,3,'craft\\elements\\Entry',1,0,'2023-03-13 09:16:41','2023-03-13 09:16:41',NULL,NULL,'a03fd94a-be3b-4314-abf2-f023a587989e'),(11,9,NULL,6,3,'craft\\elements\\Entry',1,0,'2023-03-13 09:16:41','2023-03-13 09:16:41',NULL,NULL,'5adf9cf0-f385-438b-ae45-661f628a658f'),(12,9,NULL,7,3,'craft\\elements\\Entry',1,0,'2023-03-13 09:16:41','2023-03-13 09:16:41',NULL,NULL,'7e7c9ad5-61ca-4843-8176-1c80f8f0d97a'),(13,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2023-03-13 09:17:00','2023-03-13 09:17:00',NULL,NULL,'d264f0f8-f7f9-4de3-8ccf-9c92b7ea4395'),(14,13,NULL,8,4,'craft\\elements\\Entry',1,0,'2023-03-13 09:17:00','2023-03-13 09:17:00',NULL,NULL,'7f2ee58d-325c-41f1-9268-26d997d7babc'),(15,13,NULL,9,4,'craft\\elements\\Entry',1,0,'2023-03-13 09:17:00','2023-03-13 09:17:00',NULL,NULL,'a935a2bd-2476-46fb-b923-fdd47b72ffe6'),(16,9,NULL,10,3,'craft\\elements\\Entry',1,0,'2023-03-13 09:17:22','2023-03-13 09:17:22',NULL,NULL,'ff6dc1ec-9bc8-40d1-a3bb-619be922339a'),(17,9,NULL,11,3,'craft\\elements\\Entry',1,0,'2023-03-13 09:17:22','2023-03-13 09:17:22',NULL,NULL,'c6f0d7d4-2e5c-4dfa-a38a-97c103308c76'),(18,2,NULL,12,1,'craft\\elements\\Entry',1,0,'2023-03-13 09:52:24','2023-03-13 09:52:24',NULL,NULL,'4bb6d99a-fd15-487c-ac0e-13d664538ecc'),(19,9,NULL,13,3,'craft\\elements\\Entry',1,0,'2023-03-13 09:52:39','2023-03-13 09:52:39',NULL,NULL,'8de88db6-bafa-4d57-8205-3f8ef86b18cd'),(21,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:53:04','2023-03-13 09:53:04',NULL,'2023-03-13 09:53:08','17abeec6-3715-4194-9ec6-defc2183f6aa'),(22,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:53:08','2023-03-13 09:53:08',NULL,'2023-03-13 09:53:11','00632229-cc10-47cf-a599-10b5399ab97a'),(23,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:53:11','2023-03-13 09:53:11',NULL,'2023-03-13 09:53:15','10760fa5-9030-447a-8572-53e55f1bc1d6'),(24,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:53:15','2023-03-13 09:53:15',NULL,'2023-03-13 09:53:18','ef490d15-3649-480c-9b5c-cc3c04a778ef'),(25,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:53:18','2023-03-13 09:53:18',NULL,'2023-03-13 09:53:20','d2c35241-72f6-4b06-be66-7c77979d4e84'),(26,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:53:20','2023-03-13 09:53:20',NULL,'2023-03-13 09:53:25','dbd470f3-e6c3-441c-9189-96351bcf48c5'),(27,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:53:25','2023-03-13 09:53:25',NULL,'2023-03-13 09:53:26','a10727ce-656f-4ec5-91ad-938cb2a3c8dc'),(28,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:53:26','2023-03-13 09:53:26',NULL,'2023-03-13 09:53:30','0a91f51e-7277-4456-bb01-bf382bfc51f7'),(29,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:53:30','2023-03-13 09:53:30',NULL,'2023-03-13 09:53:33','6483c305-c5c7-439f-95d4-712e3d87d097'),(30,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:53:33','2023-03-13 09:53:33',NULL,'2023-03-13 09:53:47','864937bc-420f-4f08-b49c-7f0054f57987'),(32,NULL,NULL,NULL,7,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:56:15','2023-03-13 09:56:15',NULL,'2023-03-13 09:56:20','e73b1bf9-13e7-4569-aa38-429a31a1c91e'),(33,NULL,NULL,NULL,7,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:56:20','2023-03-13 09:56:20',NULL,'2023-03-13 09:56:22','d3053675-312e-416f-a3e6-1c991dc0e3e2'),(34,NULL,NULL,NULL,7,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:56:22','2023-03-13 09:56:22',NULL,'2023-03-13 09:56:43','93113668-43d0-44e9-b866-65ef31da1159'),(35,NULL,NULL,NULL,7,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:56:43','2023-03-13 09:56:43',NULL,'2023-03-13 09:56:49','158726a6-14f4-45fa-b16b-f74fc275c628'),(36,NULL,NULL,NULL,7,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 09:56:49','2023-03-13 09:56:49',NULL,'2023-03-13 09:56:50','265d0c04-cfa0-424d-a6cc-6455956cf237'),(41,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2023-03-13 10:14:22','2023-03-13 10:14:22',NULL,NULL,'41770ab6-c213-4f81-88a6-6cc453ea2ee2'),(46,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2023-03-13 11:06:33','2023-03-13 11:15:35',NULL,NULL,'df553275-2f06-4456-8390-8027c0ad572c'),(47,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2023-03-13 11:15:31','2023-03-13 11:15:31',NULL,'2023-03-13 11:15:35','13ae74be-27c5-4ece-af77-b8a4925497ab'),(50,NULL,NULL,NULL,11,'craft\\elements\\Asset',1,0,'2023-03-13 11:18:46','2023-03-13 11:18:46',NULL,NULL,'3a6508d1-ff2e-40e7-b29a-21114468a2e2'),(51,NULL,NULL,NULL,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 11:20:13','2023-03-13 11:20:13',NULL,NULL,'375625ff-ab69-4808-a53f-b3dc570f36c0'),(52,NULL,NULL,NULL,7,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 11:20:13','2023-03-13 11:20:13',NULL,NULL,'878ba4c2-3504-40d1-abf1-e9692969f1cc'),(53,NULL,NULL,NULL,6,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 11:20:13','2023-03-13 11:20:13',NULL,NULL,'de409f3d-8b1d-4f66-82ac-bc8c08998058'),(54,2,NULL,14,1,'craft\\elements\\Entry',1,0,'2023-03-13 11:20:13','2023-03-13 11:20:13',NULL,NULL,'885b1077-c729-4cf3-b8e8-166725bf3c72'),(55,51,NULL,15,8,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 11:20:13','2023-03-13 11:20:13',NULL,NULL,'b659d870-5631-4f42-96f1-9a660aebf8b0'),(56,52,NULL,16,7,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 11:20:13','2023-03-13 11:20:13',NULL,NULL,'75739943-c1d5-4dd9-b056-0eed6f25c8f3'),(57,53,NULL,17,6,'craft\\elements\\MatrixBlock',1,0,'2023-03-13 11:20:13','2023-03-13 11:20:13',NULL,NULL,'fd661462-9a7c-4109-a20a-bb0ebb2ea087');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2023-03-12 17:05:10','2023-03-12 17:05:10','718650af-115f-493c-aa50-402fc76fa129'),(2,2,1,'home','__home__',1,'2023-03-13 03:54:54','2023-03-13 03:54:54','706f26fa-fd12-4948-88b5-cb197b0759d4'),(3,3,1,'home','__home__',1,'2023-03-13 03:54:54','2023-03-13 03:54:54','6e494556-2416-48f7-bb1d-96cb5ccf5ce1'),(4,4,1,'home','__home__',1,'2023-03-13 03:54:54','2023-03-13 03:54:54','8e860a8f-89a8-40d9-91ce-d20fa3ec4459'),(5,5,1,'home','__home__',1,'2023-03-13 03:55:05','2023-03-13 03:55:05','bd184d3f-a6c1-40c8-ac1b-c1e3a95e785a'),(6,6,1,'home','__home__',1,'2023-03-13 04:38:29','2023-03-13 04:38:29','3405efc2-8d8d-4344-829e-2c26c12069a9'),(7,7,1,NULL,NULL,1,'2023-03-13 08:37:14','2023-03-13 08:37:14','7dbe1857-44e5-4b4d-8772-4ea56b33b7ae'),(8,8,1,NULL,NULL,1,'2023-03-13 08:59:53','2023-03-13 08:59:53','c0b67934-eebc-4be5-8f1a-92826c6b870a'),(9,9,1,'about','about',1,'2023-03-13 09:16:41','2023-03-13 09:17:22','45e2f141-901e-4d16-9c65-ea35c0283365'),(10,10,1,'about','about',1,'2023-03-13 09:16:41','2023-03-13 09:17:22','e63c1b2d-bfac-4fd4-9e4f-565260ef8d7c'),(11,11,1,'about','about',1,'2023-03-13 09:16:41','2023-03-13 09:17:22','ecf0fb8f-43a1-422d-bfa9-7b3bae420696'),(12,12,1,'about','about',1,'2023-03-13 09:16:41','2023-03-13 09:17:22','dee9c14a-a26a-49bd-8e4c-79b079b0bacd'),(13,13,1,'contact','contact',1,'2023-03-13 09:17:00','2023-03-13 09:17:00','e3148e0d-061b-46da-acc7-f7d2846e53f1'),(14,14,1,'contact','contact',1,'2023-03-13 09:17:00','2023-03-13 09:17:00','32c256fa-3757-4acb-bdb1-b1d6617cbfae'),(15,15,1,'contact','contact',1,'2023-03-13 09:17:00','2023-03-13 09:17:00','c8827b0e-1701-4fd9-bd89-7d8d282d0c20'),(16,16,1,'about','about',1,'2023-03-13 09:17:22','2023-03-13 09:17:22','be53dce9-b3fa-4a3d-b119-30ea4785595b'),(17,17,1,'about','about',1,'2023-03-13 09:17:22','2023-03-13 09:17:22','605eb6de-5a0e-4142-9397-8fc7dbe91195'),(18,18,1,'home','__home__',1,'2023-03-13 09:52:24','2023-03-13 09:52:24','1d3649de-8a46-43eb-ae6f-b0fa99f617be'),(19,19,1,'about','about',1,'2023-03-13 09:52:39','2023-03-13 09:52:39','6b91ed30-5471-42bb-83b7-ae773ed05a09'),(21,21,1,NULL,NULL,1,'2023-03-13 09:53:04','2023-03-13 09:53:04','0fe2e440-7879-4703-af3a-073ced8d87ff'),(22,22,1,NULL,NULL,1,'2023-03-13 09:53:08','2023-03-13 09:53:08','aa712f9e-cb0f-4cc6-8763-b5b9d6b9941a'),(23,23,1,NULL,NULL,1,'2023-03-13 09:53:11','2023-03-13 09:53:11','4bd90da9-577a-4868-ba25-e9181a119322'),(24,24,1,NULL,NULL,1,'2023-03-13 09:53:15','2023-03-13 09:53:15','a389d84e-f5fd-4802-a9d3-2218078b1c08'),(25,25,1,NULL,NULL,1,'2023-03-13 09:53:18','2023-03-13 09:53:18','a9a1b101-4d29-462c-8033-a8e1af335224'),(26,26,1,NULL,NULL,1,'2023-03-13 09:53:20','2023-03-13 09:53:20','03142c2e-af8e-4318-b582-1fc009512087'),(27,27,1,NULL,NULL,1,'2023-03-13 09:53:25','2023-03-13 09:53:25','32e5098d-b617-42b1-b588-b2164e1f7578'),(28,28,1,NULL,NULL,1,'2023-03-13 09:53:26','2023-03-13 09:53:26','31e1522d-240f-425c-832e-cbced6dca747'),(29,29,1,NULL,NULL,1,'2023-03-13 09:53:30','2023-03-13 09:53:30','1eb01eb4-cad8-4420-adf5-44543e5b51f7'),(30,30,1,NULL,NULL,1,'2023-03-13 09:53:33','2023-03-13 09:53:33','c5aab525-7bdf-431a-9976-5e807cfae1af'),(32,32,1,NULL,NULL,1,'2023-03-13 09:56:15','2023-03-13 09:56:15','957766d0-d551-4d1b-9d48-2e0350ac0196'),(33,33,1,NULL,NULL,1,'2023-03-13 09:56:20','2023-03-13 09:56:20','906b4c0c-4fd4-4e4b-b587-324e7e472385'),(34,34,1,NULL,NULL,1,'2023-03-13 09:56:22','2023-03-13 09:56:22','ebe3b4b4-fb45-41b2-823e-fdd3910682a4'),(35,35,1,NULL,NULL,1,'2023-03-13 09:56:43','2023-03-13 09:56:43','84c791b1-f49f-4476-a6d8-3b4d78e6da2f'),(36,36,1,NULL,NULL,1,'2023-03-13 09:56:49','2023-03-13 09:56:49','54c0daea-11db-41fd-8437-7c44d434ade7'),(41,41,1,NULL,NULL,1,'2023-03-13 10:14:22','2023-03-13 10:14:22','d917341f-651a-4089-b013-4323efbbfa1f'),(46,46,1,NULL,NULL,1,'2023-03-13 11:06:33','2023-03-13 11:06:33','32c29429-58e9-4c72-9220-cfd5830139df'),(47,47,1,NULL,NULL,1,'2023-03-13 11:15:31','2023-03-13 11:15:31','e367776b-6047-40a2-8d94-aec925a2c743'),(50,50,1,NULL,NULL,1,'2023-03-13 11:18:46','2023-03-13 11:18:46','4050e9d5-3370-4f7c-9df4-c06db4a4f0f7'),(51,51,1,NULL,NULL,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','e96e4fb1-5ef7-4d2e-8fd7-327804da7904'),(52,52,1,NULL,NULL,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','fe6faa67-36a4-4b41-aee7-9a0e7ff474cb'),(53,53,1,NULL,NULL,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','27fbc8cf-4eba-43cd-9f2b-e06642a0564b'),(54,54,1,'home','__home__',1,'2023-03-13 11:20:13','2023-03-13 11:20:13','91dd6e3a-d42a-4e53-a3e5-59184a0f5c96'),(55,55,1,NULL,NULL,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','a8dcf49f-ab47-4caa-a400-428a92794a2e'),(56,56,1,NULL,NULL,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','9ae0dcf2-8062-4499-9687-ed911c5f000d'),(57,57,1,NULL,NULL,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','ea2131f6-d968-46b1-9911-f1bb9c5ced3c');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (2,1,NULL,1,NULL,'2023-03-13 03:54:00',NULL,NULL,'2023-03-13 03:54:54','2023-03-13 03:54:54'),(3,1,NULL,1,NULL,'2023-03-13 03:54:00',NULL,NULL,'2023-03-13 03:54:54','2023-03-13 03:54:54'),(4,1,NULL,1,NULL,'2023-03-13 03:54:00',NULL,NULL,'2023-03-13 03:54:54','2023-03-13 03:54:54'),(5,1,NULL,1,NULL,'2023-03-13 03:54:00',NULL,NULL,'2023-03-13 03:55:05','2023-03-13 03:55:05'),(6,1,NULL,1,NULL,'2023-03-13 03:54:00',NULL,NULL,'2023-03-13 04:38:29','2023-03-13 04:38:29'),(9,2,NULL,2,NULL,'2023-03-13 09:16:00',NULL,NULL,'2023-03-13 09:16:41','2023-03-13 09:16:41'),(10,2,NULL,2,NULL,'2023-03-13 09:16:00',NULL,NULL,'2023-03-13 09:16:41','2023-03-13 09:16:41'),(11,2,NULL,2,NULL,'2023-03-13 09:16:00',NULL,NULL,'2023-03-13 09:16:41','2023-03-13 09:16:41'),(12,2,NULL,2,NULL,'2023-03-13 09:16:00',NULL,NULL,'2023-03-13 09:16:41','2023-03-13 09:16:41'),(13,7,NULL,3,NULL,'2023-03-13 09:17:00',NULL,NULL,'2023-03-13 09:17:00','2023-03-13 09:17:00'),(14,7,NULL,3,NULL,'2023-03-13 09:17:00',NULL,NULL,'2023-03-13 09:17:00','2023-03-13 09:17:00'),(15,7,NULL,3,NULL,'2023-03-13 09:17:00',NULL,NULL,'2023-03-13 09:17:00','2023-03-13 09:17:00'),(16,2,NULL,2,NULL,'2023-03-13 09:16:00',NULL,NULL,'2023-03-13 09:17:22','2023-03-13 09:17:22'),(17,2,NULL,2,NULL,'2023-03-13 09:16:00',NULL,NULL,'2023-03-13 09:17:22','2023-03-13 09:17:22'),(18,1,NULL,1,NULL,'2023-03-13 03:54:00',NULL,NULL,'2023-03-13 09:52:24','2023-03-13 09:52:24'),(19,2,NULL,2,NULL,'2023-03-13 09:16:00',NULL,NULL,'2023-03-13 09:52:39','2023-03-13 09:52:39'),(54,1,NULL,1,NULL,'2023-03-13 03:54:00',NULL,NULL,'2023-03-13 11:20:13','2023-03-13 11:20:13');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,1,'Home','home',0,'site',NULL,'{section.name|raw}',1,'2023-03-13 03:54:54','2023-03-13 03:54:54',NULL,'fd107921-d306-448f-ad1a-e7c2ef60913c'),(2,2,3,'About','about',1,'site',NULL,NULL,1,'2023-03-13 09:14:13','2023-03-13 09:16:41',NULL,'8c1501f8-32b3-4150-91bc-23f988eb98e5'),(3,7,4,'Contact','contact',0,'site',NULL,'{section.name|raw}',1,'2023-03-13 09:17:00','2023-03-13 09:17:00',NULL,'09cde05d-5606-478a-8ab0-d9a6a607d414');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2023-03-12 17:05:10','2023-03-12 17:05:10',NULL,'89833881-16ce-4ec4-abfd-1f352dc99fd8'),(2,'Navigation Items','2023-03-13 08:59:43','2023-03-13 08:59:43','2023-03-13 09:01:26','91458f3d-5347-4b47-a507-b691e9a17943');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayoutfields` VALUES (10,2,11,1,0,0,'2023-03-13 09:01:54','2023-03-13 09:01:54','19672dbc-4b15-4ced-bd2d-274864ebab54'),(92,1,40,2,0,1,'2023-03-13 09:52:24','2023-03-13 09:52:24','590b69aa-ac27-47ae-b597-fefd9f6a6d96'),(93,3,41,2,0,1,'2023-03-13 09:52:39','2023-03-13 09:52:39','9c6eace8-4947-46b4-8711-11dcc553df4a'),(120,7,52,11,0,0,'2023-03-13 09:57:30','2023-03-13 09:57:30','9a074ce2-5852-4e65-a066-115cb7d94cda'),(121,7,52,10,0,1,'2023-03-13 09:57:30','2023-03-13 09:57:30','d7659d07-dde5-4f13-a226-be8a30fce073'),(123,10,54,18,1,0,'2023-03-13 09:57:30','2023-03-13 09:57:30','1a130e96-678b-4645-bf33-c12ae177e302'),(124,10,54,19,1,1,'2023-03-13 09:57:30','2023-03-13 09:57:30','3c2c56ce-278e-457e-bfb2-bfde742416a4'),(125,10,54,17,1,2,'2023-03-13 09:57:30','2023-03-13 09:57:30','c2da73c4-bf30-4740-bb05-73879aa89bc9'),(126,8,56,12,0,0,'2023-03-13 10:07:03','2023-03-13 10:07:03','d45bfd73-4b3b-4781-a96d-4919030f7271'),(127,8,56,13,1,1,'2023-03-13 10:07:03','2023-03-13 10:07:03','ca301623-5822-4f62-ace8-d2a2c4a26204'),(128,8,56,15,1,2,'2023-03-13 10:07:03','2023-03-13 10:07:03','2b5e12e7-f097-4adb-b8e2-a59018cfa0ac'),(129,8,56,14,1,3,'2023-03-13 10:07:03','2023-03-13 10:07:03','c072719c-df06-4c06-8b3a-d24059e5de3e'),(130,6,57,6,0,0,'2023-03-13 10:07:03','2023-03-13 10:07:03','066316f2-19bb-44b1-bf60-9b2f52595a21'),(131,6,57,9,1,1,'2023-03-13 10:07:03','2023-03-13 10:07:03','e9f7dc28-34c9-4347-a08a-91c76b169547'),(132,6,57,7,1,2,'2023-03-13 10:07:03','2023-03-13 10:07:03','754b8a1e-e48c-4913-b610-119278b9b4e1'),(133,6,57,5,0,3,'2023-03-13 10:07:03','2023-03-13 10:07:03','6915ba99-d612-4939-94e7-0bee3c004dd8'),(134,6,57,4,0,4,'2023-03-13 10:07:03','2023-03-13 10:07:03','aadda84e-67dd-47fd-bbdb-fd6beadd1c72'),(135,6,57,8,0,5,'2023-03-13 10:07:03','2023-03-13 10:07:03','77e4f1ef-a666-475c-964b-abce87f8d4b7'),(136,9,58,16,1,0,'2023-03-13 10:07:03','2023-03-13 10:07:03','ce03cd91-ea5a-4ea3-a702-431af31272e8');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2023-03-13 03:54:54','2023-03-13 03:54:54',NULL,'bd83878c-9e00-41e7-ab49-51e0ca66e33c'),(2,'craft\\elements\\GlobalSet','2023-03-13 08:59:53','2023-03-13 09:01:54',NULL,'9d72560f-07d2-42ea-87b5-62c13b9aa05b'),(3,'craft\\elements\\Entry','2023-03-13 09:14:13','2023-03-13 09:14:13',NULL,'44eefc40-e6d2-4005-93f2-60e163f7e545'),(4,'craft\\elements\\Entry','2023-03-13 09:17:00','2023-03-13 09:17:00',NULL,'2a94f0a0-f313-4ec1-97f7-c7da258786dd'),(5,'craft\\elements\\MatrixBlock','2023-03-13 09:33:16','2023-03-13 09:33:16','2023-03-13 09:52:06','1eba8cc3-4de1-4c46-bf03-c54eb770ad9f'),(6,'craft\\elements\\MatrixBlock','2023-03-13 09:33:16','2023-03-13 09:33:16',NULL,'09f77758-0e87-4658-8750-d44df13f6a10'),(7,'craft\\elements\\MatrixBlock','2023-03-13 09:33:17','2023-03-13 09:33:17',NULL,'305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d'),(8,'craft\\elements\\MatrixBlock','2023-03-13 09:52:06','2023-03-13 09:52:06',NULL,'21c9356a-52c7-44c1-9232-60d247a5b475'),(9,'craft\\elements\\MatrixBlock','2023-03-13 09:55:55','2023-03-13 09:55:55',NULL,'846e10fa-cb8e-498b-ada3-fdd0b84bc91c'),(10,'craft\\elements\\MatrixBlock','2023-03-13 09:55:55','2023-03-13 09:55:55',NULL,'67b3defe-82e7-4613-9aa0-0a6c02bc0b02'),(11,'craft\\elements\\Asset','2023-03-13 10:06:24','2023-03-13 10:06:24',NULL,'955f302c-0132-4014-8378-b2ed1caaf11f');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (11,2,'Navigation','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"686ffd67-369d-46ed-b41a-92ebacedf32f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"91458f3d-5347-4b47-a507-b691e9a17943\"}]',1,'2023-03-13 09:01:54','2023-03-13 09:01:54','328f8abf-19f4-44cb-bc68-65381792c18f'),(14,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"0ce42f51-e53c-4a8c-bc88-1f7911c037f9\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-03-13 09:17:00','2023-03-13 09:17:00','399bee4f-19bf-4cf7-83dc-5acc8aeeb3b9'),(33,5,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"d3d2f5c8-87bb-4840-ac8e-e7ba61e8e319\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"687cd2f1-06f5-4174-ab03-40daaa93ad90\"}]',1,'2023-03-13 09:38:32','2023-03-13 09:38:32','d41124fc-9cf6-42e4-9633-b29b78455a1e'),(40,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"c75b3005-683c-4927-97a4-96f2ed28b58f\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"a57c9410-acaf-4d25-9c0a-3dc327c06032\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"745cf2fc-6457-41df-a21e-131f47a52823\"}]',1,'2023-03-13 09:52:24','2023-03-13 09:52:24','8667d96b-885f-4199-9aaf-98330837c079'),(41,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"3bf2a346-859c-41b9-9528-9430ab9a2f91\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"396d0599-4a5e-442d-aa43-661d78e9111a\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"745cf2fc-6457-41df-a21e-131f47a52823\"}]',1,'2023-03-13 09:52:39','2023-03-13 09:52:39','7db536ab-5c65-45b2-bf7d-182e006ca1d2'),(52,7,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"2135836d-280a-40a2-8639-bd0cf29c70c9\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"85e4d323-90fe-4f06-8e83-6bb8a14dbe52\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"1da30993-295b-40b9-aab0-24e5a9812929\"}]',1,'2023-03-13 09:57:30','2023-03-13 09:57:30','4f5030ff-d953-4be0-aba7-8d3a83b83a1a'),(54,10,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"965e5b68-9fb4-420f-b6be-7bf75d5d16ff\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"0d01ac2a-6f7f-4925-8c97-10d917e18c84\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"0af1f30c-23c0-412d-8cd9-56043147e74e\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"6dc1ef68-7606-4254-8f3e-ab00a4a0b146\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"548b0e08-7744-4dd9-be93-431f94f05c9e\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"0afdac73-846a-4985-a071-851fed756ca9\"}]',1,'2023-03-13 09:57:30','2023-03-13 09:57:30','9106d75e-ab2e-4394-989c-e5865e75ee12'),(56,8,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"f95608b1-f109-480b-879f-dd5b14c87e42\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"5e672526-c38e-4fdc-b248-363c3c83ef20\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"b40f3b0d-7728-400a-a981-73e951a9df58\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"9d42013b-11c6-42cf-b45b-fa037c8bcaba\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"7d62808f-9bdc-4dbc-a381-93efed6570fa\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"de802f05-8a3d-4fbd-99ee-3188ab50874c\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"57d2a439-5ee2-4ace-a33f-be0f69c7716d\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"ce352345-5dc4-4b53-a997-af7ff50bf606\"}]',1,'2023-03-13 10:07:03','2023-03-13 10:07:03','027dd33a-c8fb-403b-abf0-04290cd0356f'),(57,6,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"396067c7-0eca-458e-b983-f44a9df6daf8\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"95ecac41-0668-4b7c-a8ac-8ec14d07b5af\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"dfe609b6-1246-47a6-ba40-e82290f5ba75\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"fe4b113d-bf1c-4f36-806f-80cb15f3cac8\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"529cd31b-fe7e-45c6-8833-985ad227c53e\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"114dbb25-d74a-43df-9136-bbc8e4bdeaec\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"0ea3fdb0-2b83-4152-ad0d-47dd579771b9\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"36e3ae0f-08a5-4193-af58-4ed32c350d94\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"71715eeb-b5f3-48ec-9aaa-435f18525e06\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"581dde12-0661-476b-adbd-8015ea94a58e\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"e58e1829-76c2-476c-bf92-2f56e2f3900e\"}]',1,'2023-03-13 10:07:03','2023-03-13 10:07:03','00f73aed-2f65-4a99-852b-a103a01c4031'),(58,9,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"dd751407-aa30-4745-b0a5-72d422753bde\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"5bb2582c-1b3b-4a0a-b234-64558f60c9a9\"}]',1,'2023-03-13 10:07:03','2023-03-13 10:07:03','2ac12cc5-ad94-48a7-849b-67ac92f395b2'),(59,11,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"dca2f5cd-1a06-4bd0-94bf-7f620a3fea5d\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\",\"attribute\":\"alt\",\"requirable\":true,\"class\":null,\"rows\":null,\"cols\":null,\"name\":null,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"5e4bda1a-14ad-45e9-acbf-7cf61cbe4c36\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-03-13 10:16:26','2023-03-13 10:16:26','e8091142-5b46-4e2a-86ac-1e10416d5671');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,1,'Navigation Items','navigationItems','global','bkoedaxb',NULL,0,'none',NULL,'craft\\fields\\Table','{\"addRowLabel\":\"Add a row\",\"columnType\":\"text\",\"columns\":{\"col1\":{\"heading\":\"Title\",\"handle\":\"title\",\"width\":\"\",\"type\":\"singleline\"},\"col2\":{\"heading\":\"Path\",\"handle\":\"path\",\"width\":\"\",\"type\":\"url\"}},\"defaults\":[{\"col1\":\"\",\"col2\":\"\"}],\"maxRows\":null,\"minRows\":null}','2023-03-13 08:59:53','2023-03-13 09:38:40','91458f3d-5347-4b47-a507-b691e9a17943'),(2,1,'Content','contentPanels','global',NULL,'Add, remove or reorder content panels',0,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":null,\"maxBlocks\":null,\"contentTable\":\"{{%matrixcontent_contentpanels}}\",\"propagationMethod\":\"all\",\"propagationKeyFormat\":null}','2023-03-13 09:33:16','2023-03-13 09:57:30','745cf2fc-6457-41df-a21e-131f47a52823'),(4,NULL,'Button Text','heroButtonText','matrixBlockType:0d3d2425-6d71-474f-9ff8-bbaa45b837c5',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-03-13 09:33:16','2023-03-13 09:57:30','4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6'),(5,NULL,'Image','image','matrixBlockType:0d3d2425-6d71-474f-9ff8-bbaa45b837c5',NULL,'Image',0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2023-03-13 09:33:16','2023-03-13 10:07:03','36e3ae0f-08a5-4193-af58-4ed32c350d94'),(6,NULL,'Subject','subject','matrixBlockType:0d3d2425-6d71-474f-9ff8-bbaa45b837c5',NULL,'Subject',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":64,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Subject\",\"uiMode\":\"normal\"}','2023-03-13 09:33:16','2023-03-13 09:57:30','95ecac41-0668-4b7c-a8ac-8ec14d07b5af'),(7,NULL,'Content','panelContent','matrixBlockType:0d3d2425-6d71-474f-9ff8-bbaa45b837c5',NULL,'Content',0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":null,\"removeEmptyTags\":true,\"removeInlineStyles\":true,\"removeNbsp\":true,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2023-03-13 09:33:16','2023-03-13 09:57:30','114dbb25-d74a-43df-9136-bbc8e4bdeaec'),(8,NULL,'Button Link','heroButtonHref','matrixBlockType:0d3d2425-6d71-474f-9ff8-bbaa45b837c5',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-03-13 09:33:16','2023-03-13 09:57:30','e58e1829-76c2-476c-bf92-2f56e2f3900e'),(9,NULL,'Title','panelTitle','matrixBlockType:0d3d2425-6d71-474f-9ff8-bbaa45b837c5',NULL,'Title',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":64,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Title\",\"uiMode\":\"normal\"}','2023-03-13 09:33:16','2023-03-13 09:57:30','fe4b113d-bf1c-4f36-806f-80cb15f3cac8'),(10,NULL,'Panel Subheading','panelSubheading','matrixBlockType:220d125c-af88-4a55-9b6c-ddae8a634855',NULL,'Panel Subheading',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Panel Subheading\",\"uiMode\":\"enlarged\"}','2023-03-13 09:33:16','2023-03-13 09:38:32','1da30993-295b-40b9-aab0-24e5a9812929'),(11,NULL,'Panel Title','panelTitle','matrixBlockType:220d125c-af88-4a55-9b6c-ddae8a634855',NULL,'Panel Title',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":128,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Panel Title\",\"uiMode\":\"normal\"}','2023-03-13 09:33:17','2023-03-13 09:38:32','79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2'),(12,NULL,'Subject','subject','matrixBlockType:c84251ed-c157-4470-8a0b-fa532933274f',NULL,'Subject',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":64,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Subject\",\"uiMode\":\"normal\"}','2023-03-13 09:52:06','2023-03-13 09:57:30','5e672526-c38e-4fdc-b248-363c3c83ef20'),(13,NULL,'Title','panelTitle','matrixBlockType:c84251ed-c157-4470-8a0b-fa532933274f',NULL,'Title',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":256,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Title\",\"uiMode\":\"normal\"}','2023-03-13 09:52:06','2023-03-13 09:57:30','9d42013b-11c6-42cf-b45b-fa037c8bcaba'),(14,NULL,'Image','image','matrixBlockType:c84251ed-c157-4470-8a0b-fa532933274f',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2023-03-13 09:52:06','2023-03-13 10:07:03','ce352345-5dc4-4b53-a997-af7ff50bf606'),(15,NULL,'Content','panelContent','matrixBlockType:c84251ed-c157-4470-8a0b-fa532933274f',NULL,'Content',0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":null,\"removeEmptyTags\":true,\"removeInlineStyles\":true,\"removeNbsp\":true,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2023-03-13 09:52:06','2023-03-13 09:57:30','de802f05-8a3d-4fbd-99ee-3188ab50874c'),(16,NULL,'Image','image','matrixBlockType:42a3ddcd-d834-49a3-a79e-21c3f11a6ab6',NULL,'Add image',0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2023-03-13 09:55:55','2023-03-13 10:07:03','5bb2582c-1b3b-4a0a-b234-64558f60c9a9'),(17,NULL,'Button Text','buttonText','matrixBlockType:78ee6ec1-b0de-4912-a9f9-ced7e4c1646e',NULL,'Button Text',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":64,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Button Text\",\"uiMode\":\"normal\"}','2023-03-13 09:55:55','2023-03-13 09:57:30','0afdac73-846a-4985-a071-851fed756ca9'),(18,NULL,'Title','panelTitle','matrixBlockType:78ee6ec1-b0de-4912-a9f9-ced7e4c1646e',NULL,'Title',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":128,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Title\",\"uiMode\":\"normal\"}','2023-03-13 09:55:55','2023-03-13 09:57:30','0d01ac2a-6f7f-4925-8c97-10d917e18c84'),(19,NULL,'Button Link','buttonHref','matrixBlockType:78ee6ec1-b0de-4912-a9f9-ced7e4c1646e',NULL,'Button Link',0,'none',NULL,'craft\\fields\\Url','{\"maxLength\":255,\"types\":[\"url\"]}','2023-03-13 09:55:55','2023-03-13 09:57:30','6dc1ef68-7606-4254-8f3e-ab00a4a0b146');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `globalsets` VALUES (7,'Primary Navigation','primaryNavigation',2,2,'2023-03-13 08:37:14','2023-03-13 08:59:53','8321f181-1adc-441d-9199-5af52c1c14a4'),(8,'Primary Navigation','primaryNavigation',2,2,'2023-03-13 08:59:53','2023-03-13 08:59:53','3a25d975-5d0c-431a-94d6-a3a578faebf1');
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'4.4.1','4.4.0.4',0,'fhhbjrjuxevu','3@bssnoschaj','2023-03-12 17:05:10','2023-03-13 11:19:03','8ade0099-407c-439b-8acb-c0c17e6fc57e');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks` VALUES (51,2,2,4,NULL,'2023-03-13 11:20:13','2023-03-13 11:20:13'),(52,2,2,3,NULL,'2023-03-13 11:20:13','2023-03-13 11:20:13'),(53,2,2,2,NULL,'2023-03-13 11:20:13','2023-03-13 11:20:13'),(55,54,2,4,NULL,'2023-03-13 11:20:13','2023-03-13 11:20:13'),(56,54,2,3,NULL,'2023-03-13 11:20:13','2023-03-13 11:20:13'),(57,54,2,2,NULL,'2023-03-13 11:20:13','2023-03-13 11:20:13');
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks_owners` VALUES (51,2,1),(52,2,2),(53,2,3),(55,54,1),(56,54,2),(57,54,3);
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocktypes` VALUES (2,2,6,'Hero Panel (Dark)','heroPanelDark',2,'2023-03-13 09:33:16','2023-03-13 09:52:06','0d3d2425-6d71-474f-9ff8-bbaa45b837c5'),(3,2,7,'Content Panel','contentPanel',3,'2023-03-13 09:33:17','2023-03-13 09:57:30','220d125c-af88-4a55-9b6c-ddae8a634855'),(4,2,8,'Hero Panel','heroPanel',1,'2023-03-13 09:52:06','2023-03-13 09:52:06','c84251ed-c157-4470-8a0b-fa532933274f'),(5,2,9,'Image panel','imagePanel',4,'2023-03-13 09:55:55','2023-03-13 09:55:55','42a3ddcd-d834-49a3-a79e-21c3f11a6ab6'),(6,2,10,'Call To Action Panel','callToAction',5,'2023-03-13 09:55:55','2023-03-13 09:57:30','78ee6ec1-b0de-4912-a9f9-ced7e4c1646e');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_contentpanels`
--

LOCK TABLES `matrixcontent_contentpanels` WRITE;
/*!40000 ALTER TABLE `matrixcontent_contentpanels` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_contentpanels` VALUES (1,21,1,'2023-03-13 09:53:04','2023-03-13 09:53:04','d2e049f9-876c-4c87-9b9c-e5969bd89ca6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,22,1,'2023-03-13 09:53:08','2023-03-13 09:53:08','8703efbb-be9d-4ae3-b3d8-5ff8102c4cd4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Hello',NULL,NULL,NULL,NULL,NULL),(3,23,1,'2023-03-13 09:53:11','2023-03-13 09:53:11','b2b556d5-27e3-4ef5-8569-9989a9d9009c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Hello',NULL,NULL,NULL,NULL,NULL),(4,24,1,'2023-03-13 09:53:15','2023-03-13 09:53:15','29ea0b8c-6a5f-40db-8c50-c97f332587e2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hero Panel Title',NULL,NULL,NULL,NULL,NULL),(5,25,1,'2023-03-13 09:53:18','2023-03-13 09:53:18','1e530d8a-22d5-4e86-9971-1cef05aa7302',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,26,1,'2023-03-13 09:53:20','2023-03-13 09:53:20','4d2d57a5-691a-4867-b433-707551c7453f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hero Panel Title',NULL,NULL,NULL,NULL),(7,27,1,'2023-03-13 09:53:25','2023-03-13 09:53:25','f51988d7-c457-4e5b-956b-e33ab589a165',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ero Panel Title',NULL,NULL,NULL,NULL),(8,28,1,'2023-03-13 09:53:26','2023-03-13 09:53:26','837bbee1-5fc9-4d52-a45d-a2e804585e4d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Hero Panel Title',NULL,NULL,NULL,NULL),(9,29,1,'2023-03-13 09:53:30','2023-03-13 09:53:30','5c3e0b81-9965-40cb-b683-b3a10cd31af7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Subject','Hero Panel Title',NULL,NULL,NULL,NULL),(10,30,1,'2023-03-13 09:53:33','2023-03-13 09:53:33','afadde8a-8b60-4947-adaf-e0c95ef5dfee',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Subject','Hero Panel Title','<p>Hello</p>',NULL,NULL,NULL),(12,32,1,'2023-03-13 09:56:15','2023-03-13 09:56:15','8b467149-1ad1-447e-8009-acaeb4d29610',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,33,1,'2023-03-13 09:56:20','2023-03-13 09:56:20','f54d2e29-5ab6-4914-9afc-89cb7be11ada',NULL,NULL,NULL,NULL,NULL,NULL,'Hello',NULL,NULL,NULL,NULL,NULL,NULL),(14,34,1,'2023-03-13 09:56:22','2023-03-13 09:56:22','f4de975b-9a03-402d-95ae-0b26d86bf289',NULL,NULL,NULL,NULL,NULL,'wassup','Hello',NULL,NULL,NULL,NULL,NULL,NULL),(15,35,1,'2023-03-13 09:56:43','2023-03-13 09:56:43','374da99a-ef22-4be1-9d0c-2c14d366b428',NULL,NULL,NULL,NULL,NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque molestie pulvinar elit sed cursus. Quisque vulputate lobortis pellentesque. Ut varius venenatis libero, id pretium arcu ultricies vel. Suspendisse potenti. Ut accumsan sit amet dui vel malesuada. In dapibus risus magna, vitae iaculis ipsum rhoncus ut. Aliquam dignissim sit amet enim eu pharetra. Sed vitae lectus ut nunc venenatis consectetur. Proin hendrerit ac turpis posuere posuere. Proin felis felis, tincidunt nec vestibulum sit amet, egestas ac ex. Integer congue, libero eu ullamcorper lobortis, mi sem varius purus, eu hendrerit lorem lorem in magna. Pellentesque in porttitor ligula, sed hendrerit est.','Hello',NULL,NULL,NULL,NULL,NULL,NULL),(16,36,1,'2023-03-13 09:56:49','2023-03-13 09:56:49','32e15d61-92c2-4042-b385-b72446c3cc81',NULL,NULL,NULL,NULL,NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque molestie pulvinar elit sed cursus. Quisque vulputate lobortis pellentesque. Ut varius venenatis libero, id pretium arcu ultricies vel. Suspendisse potenti. Ut accumsan sit amet dui vel malesuada. In dapibus risus magna, vitae iaculis ipsum rhoncus ut. Aliquam dignissim sit amet enim eu pharetra. Sed vitae lectus ut nunc venenatis consectetur. Proin hendrerit ac turpis posuere posuere. Proin felis felis, tincidunt nec vestibulum sit amet, egestas ac ex. Integer congue, libero eu ullamcorper lobortis, mi sem varius purus, eu hendrerit lorem lorem in magna. Pellentesque in porttitor ligula, sed hendrerit est.','Panel',NULL,NULL,NULL,NULL,NULL,NULL),(19,51,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','0bead687-3ec2-4f2c-a6d3-ef1d92fb5fda',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Subject','Hero Panel Title','<p>lorem ipsum</p>',NULL,NULL,NULL),(20,52,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','743ac6a2-6766-4303-a485-56b051da4acd',NULL,NULL,NULL,NULL,NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque molestie pulvinar elit sed cursus. Quisque vulputate lobortis pellentesque. Ut varius venenatis libero, id pretium arcu ultricies vel. Suspendisse potenti. Ut accumsan sit amet dui vel malesuada. In dapibus risus magna, vitae iaculis ipsum rhoncus ut. Aliquam dignissim sit amet enim eu pharetra. Sed vitae lectus ut nunc venenatis consectetur. Proin hendrerit ac turpis posuere posuere. Proin felis felis, tincidunt nec vestibulum sit amet, egestas ac ex. Integer congue, libero eu ullamcorper lobortis, mi sem varius purus, eu hendrerit lorem lorem in magna. Pellentesque in porttitor ligula, sed hendrerit est.','Panel Title',NULL,NULL,NULL,NULL,NULL,NULL),(21,53,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','142aafa6-3a2f-4cf4-b554-cfb39674f944','Learn More','Heya','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque molestie pulvinar elit sed cursus. Quisque vulputate lobortis pellentesque. Ut varius venenatis libero, id pretium arcu ultricies vel. Suspendisse potenti. Ut accumsan sit amet dui vel malesuada. In dapibus risus magna, vitae iaculis ipsum rhoncus ut. Aliquam dignissim sit amet enim eu pharetra. Sed vitae lectus ut nunc venenatis consectetur. Proin hendrerit ac turpis posuere posuere. Proin felis felis, tincidunt nec vestibulum sit amet, egestas ac ex. Integer congue, libero eu ullamcorper lobortis, mi sem varius purus, eu hendrerit lorem lorem in magna. Pellentesque in porttitor ligula, sed hendrerit est.</p>','/about','Hero Panel Title Dark',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,55,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','ad6a33ab-58ba-4eb3-897e-0a3efbc69cc7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Subject','Hero Panel Title','<p>lorem ipsum</p>',NULL,NULL,NULL),(23,56,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','2d9ecdff-81be-4c0a-bc4b-ef29eed26b46',NULL,NULL,NULL,NULL,NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque molestie pulvinar elit sed cursus. Quisque vulputate lobortis pellentesque. Ut varius venenatis libero, id pretium arcu ultricies vel. Suspendisse potenti. Ut accumsan sit amet dui vel malesuada. In dapibus risus magna, vitae iaculis ipsum rhoncus ut. Aliquam dignissim sit amet enim eu pharetra. Sed vitae lectus ut nunc venenatis consectetur. Proin hendrerit ac turpis posuere posuere. Proin felis felis, tincidunt nec vestibulum sit amet, egestas ac ex. Integer congue, libero eu ullamcorper lobortis, mi sem varius purus, eu hendrerit lorem lorem in magna. Pellentesque in porttitor ligula, sed hendrerit est.','Panel Title',NULL,NULL,NULL,NULL,NULL,NULL),(24,57,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','606a9bf7-5efe-4f35-924d-483c0290bb38','Learn More','Heya','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque molestie pulvinar elit sed cursus. Quisque vulputate lobortis pellentesque. Ut varius venenatis libero, id pretium arcu ultricies vel. Suspendisse potenti. Ut accumsan sit amet dui vel malesuada. In dapibus risus magna, vitae iaculis ipsum rhoncus ut. Aliquam dignissim sit amet enim eu pharetra. Sed vitae lectus ut nunc venenatis consectetur. Proin hendrerit ac turpis posuere posuere. Proin felis felis, tincidunt nec vestibulum sit amet, egestas ac ex. Integer congue, libero eu ullamcorper lobortis, mi sem varius purus, eu hendrerit lorem lorem in magna. Pellentesque in porttitor ligula, sed hendrerit est.</p>','/about','Hero Panel Title Dark',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `matrixcontent_contentpanels` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','6f4e093f-c084-42f9-99bb-dad5de2d7967'),(2,'craft','m210121_145800_asset_indexing_changes','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','6c187e33-5c59-4eec-9a72-ede3e0dd818f'),(3,'craft','m210624_222934_drop_deprecated_tables','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','64f373b1-9c3a-4b02-8b14-c256e2b75879'),(4,'craft','m210724_180756_rename_source_cols','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','912523df-de20-4abb-a04d-6d6814b90b70'),(5,'craft','m210809_124211_remove_superfluous_uids','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','d7a07287-f92b-45e1-88a5-415f1fd4e398'),(6,'craft','m210817_014201_universal_users','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','eea045c6-c92a-45b6-bba1-7ae9eb926bea'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','96225dfa-6255-4d66-928f-3dc782a330c7'),(8,'craft','m211115_135500_image_transformers','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','f5a6541b-e803-4792-9f09-e52c427547ed'),(9,'craft','m211201_131000_filesystems','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','2ca33282-2967-4a3e-8420-047d0fdf3f5e'),(10,'craft','m220103_043103_tab_conditions','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','410e48be-e115-4367-af90-3cb3629e831e'),(11,'craft','m220104_003433_asset_alt_text','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','679d1c1c-3c13-49f3-bc23-34dbf399130a'),(12,'craft','m220123_213619_update_permissions','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','221daeb7-6899-419a-a210-cc964bc4ed8a'),(13,'craft','m220126_003432_addresses','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','33e6f2e5-335d-4e95-9bcd-a0ed3b1e7165'),(14,'craft','m220209_095604_add_indexes','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','b3754976-4a9e-405c-beab-5d133808f35e'),(15,'craft','m220213_015220_matrixblocks_owners_table','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','2b2eaa40-53d4-441f-a0dd-102386980a6a'),(16,'craft','m220214_000000_truncate_sessions','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','321d9ea4-2e95-46bc-a4b3-c9f20aa6d0d6'),(17,'craft','m220222_122159_full_names','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','2e58640c-d5b2-4f33-bb69-077b2dedd6b2'),(18,'craft','m220223_180559_nullable_address_owner','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','4e8fc1df-0d32-40c6-b0da-f04f6afbed7f'),(19,'craft','m220225_165000_transform_filesystems','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','987e4d76-c2e0-4172-99ca-df5b6632ff5d'),(20,'craft','m220309_152006_rename_field_layout_elements','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','a4fe90f0-2050-4241-bdfd-177f109977f2'),(21,'craft','m220314_211928_field_layout_element_uids','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','d91b68b7-f4ea-4086-898c-3ae52776260b'),(22,'craft','m220316_123800_transform_fs_subpath','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','4bc53111-29ee-40be-b2d8-35a063d30f77'),(23,'craft','m220317_174250_release_all_jobs','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','cbe665e7-26aa-4661-be29-077a0ece5f55'),(24,'craft','m220330_150000_add_site_gql_schema_components','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','49720971-0879-4dc3-9a41-04000b95831a'),(25,'craft','m220413_024536_site_enabled_string','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','e8829097-af5c-4eb1-b909-556a2e3b4f2e'),(26,'craft','m221027_160703_add_image_transform_fill','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','e4906902-5022-4000-841b-10b9120cf7c4'),(27,'craft','m221028_130548_add_canonical_id_index','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','45216dc1-c64c-4c70-a835-afc0aede26ab'),(28,'craft','m221118_003031_drop_element_fks','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','e2178b18-6ca5-44f3-bb04-0893314e043c'),(29,'craft','m230131_120713_asset_indexing_session_new_options','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','6f91ecfc-a84d-478a-9aa2-e526cf5f68c7'),(30,'craft','m230226_013114_drop_plugin_license_columns','2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-12 17:05:10','908c6347-6bae-492a-86dd-b2ae08c3bfba'),(31,'plugin:redactor','m180430_204710_remove_old_plugins','2023-03-13 03:50:35','2023-03-13 03:50:35','2023-03-13 03:50:35','5d28b005-c7ae-4a31-9d97-ca6199c52f09'),(32,'plugin:redactor','Install','2023-03-13 03:50:35','2023-03-13 03:50:35','2023-03-13 03:50:35','412b8e81-8d35-405d-bc29-4eac3245c351'),(33,'plugin:redactor','m190225_003922_split_cleanup_html_settings','2023-03-13 03:50:35','2023-03-13 03:50:35','2023-03-13 03:50:35','d81d393a-97b7-48bd-abc2-81cf40963dba'),(34,'plugin:seo','Install','2023-03-13 03:51:46','2023-03-13 03:51:46','2023-03-13 03:51:46','2127a208-57dd-48de-bda0-c963abe929fd'),(35,'plugin:seo','m180906_152947_add_site_id_to_redirects','2023-03-13 03:51:46','2023-03-13 03:51:46','2023-03-13 03:51:46','9618f5d5-8076-4c94-a6d9-12ffd6129950'),(36,'plugin:seo','m190114_152300_upgrade_to_new_data_format','2023-03-13 03:51:46','2023-03-13 03:51:46','2023-03-13 03:51:46','48266cec-8a65-4b71-b225-6fd27d47ace2'),(37,'plugin:seo','m200518_110721_add_order_to_redirects','2023-03-13 03:51:46','2023-03-13 03:51:46','2023-03-13 03:51:46','2167337c-f2dc-4433-956e-05cf922be6a4'),(38,'plugin:seo','m201207_124200_add_product_types_to_sitemap','2023-03-13 03:51:46','2023-03-13 03:51:46','2023-03-13 03:51:46','84bf40db-6fba-411f-846d-d442ed5e6d1d');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'redactor','3.0.3','2.3.0','2023-03-13 03:50:35','2023-03-13 03:50:35','2023-03-13 03:50:35','68dddbe2-e8bd-48c3-882f-ebf17b1f1854'),(2,'contact-form','3.0.0','1.0.0','2023-03-13 03:51:17','2023-03-13 03:51:17','2023-03-13 03:51:17','aa3b0bb0-b8ba-47b0-8a7a-777baa98ae8c'),(3,'seo','v4.0.3','3.2.0','2023-03-13 03:51:46','2023-03-13 03:51:46','2023-03-13 03:51:46','61cb2374-604d-4ec0-a768-eefe38711b53');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('dateModified','1678706343'),('email.fromEmail','\"corey.james.keller@gmail.com\"'),('email.fromName','\"Waterloo Innovation Park\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elementCondition','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.autocapitalize','true'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.autocomplete','false'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.autocorrect','true'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.class','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.disabled','false'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.elementCondition','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.id','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.instructions','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.label','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.max','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.min','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.name','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.orientation','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.placeholder','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.readonly','false'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.requirable','false'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.size','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.step','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.tip','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.title','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.uid','\"0ce42f51-e53c-4a8c-bc88-1f7911c037f9\"'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.userCondition','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.warning','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.elements.0.width','100'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.name','\"Content\"'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.uid','\"399bee4f-19bf-4cf7-83dc-5acc8aeeb3b9\"'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.fieldLayouts.2a94f0a0-f313-4ec1-97f7-c7da258786dd.tabs.0.userCondition','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.handle','\"contact\"'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.hasTitleField','false'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.name','\"Contact\"'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.section','\"c21e6094-c48b-4da7-b900-dd593e0d4125\"'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.sortOrder','1'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.titleFormat','\"{section.name|raw}\"'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.titleTranslationKeyFormat','null'),('entryTypes.09cde05d-5606-478a-8ab0-d9a6a607d414.titleTranslationMethod','\"site\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elementCondition','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.autocapitalize','true'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.autocomplete','false'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.autocorrect','true'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.class','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.disabled','false'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.elementCondition','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.id','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.instructions','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.label','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.max','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.min','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.name','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.orientation','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.placeholder','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.readonly','false'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.requirable','false'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.size','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.step','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.tip','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.title','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.uid','\"3bf2a346-859c-41b9-9528-9430ab9a2f91\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.userCondition','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.warning','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.0.width','100'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.elementCondition','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.fieldUid','\"745cf2fc-6457-41df-a21e-131f47a52823\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.instructions','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.label','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.required','false'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.tip','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.uid','\"396d0599-4a5e-442d-aa43-661d78e9111a\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.userCondition','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.warning','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.elements.1.width','100'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.name','\"Content\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.uid','\"7db536ab-5c65-45b2-bf7d-182e006ca1d2\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.fieldLayouts.44eefc40-e6d2-4005-93f2-60e163f7e545.tabs.0.userCondition','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.handle','\"about\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.hasTitleField','true'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.name','\"About\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.section','\"ee51cfa4-ec13-4103-bf30-68e7c1b63ac5\"'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.sortOrder','1'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.titleFormat','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.titleTranslationKeyFormat','null'),('entryTypes.8c1501f8-32b3-4150-91bc-23f988eb98e5.titleTranslationMethod','\"site\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elementCondition','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.autocapitalize','true'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.autocomplete','false'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.autocorrect','true'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.class','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.disabled','false'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.elementCondition','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.id','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.instructions','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.label','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.max','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.min','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.name','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.orientation','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.placeholder','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.readonly','false'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.requirable','false'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.size','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.step','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.tip','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.title','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.uid','\"c75b3005-683c-4927-97a4-96f2ed28b58f\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.userCondition','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.warning','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.0.width','100'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.elementCondition','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.fieldUid','\"745cf2fc-6457-41df-a21e-131f47a52823\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.instructions','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.label','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.required','false'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.tip','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.uid','\"a57c9410-acaf-4d25-9c0a-3dc327c06032\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.userCondition','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.warning','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.elements.1.width','100'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.name','\"Content\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.uid','\"8667d96b-885f-4199-9aaf-98330837c079\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.fieldLayouts.bd83878c-9e00-41e7-ab49-51e0ca66e33c.tabs.0.userCondition','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.handle','\"home\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.hasTitleField','false'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.name','\"Home\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.section','\"d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.sortOrder','1'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.titleFormat','\"{section.name|raw}\"'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.titleTranslationKeyFormat','null'),('entryTypes.fd107921-d306-448f-ad1a-e7c2ef60913c.titleTranslationMethod','\"site\"'),('fieldGroups.89833881-16ce-4ec4-abfd-1f352dc99fd8.name','\"Common\"'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.columnSuffix','null'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.contentColumnType','\"string\"'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.fieldGroup','\"89833881-16ce-4ec4-abfd-1f352dc99fd8\"'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.handle','\"contentPanels\"'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.instructions','\"Add, remove or reorder content panels\"'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.name','\"Content\"'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.searchable','false'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.settings.contentTable','\"{{%matrixcontent_contentpanels}}\"'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.settings.maxBlocks','null'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.settings.minBlocks','null'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.settings.propagationKeyFormat','null'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.settings.propagationMethod','\"all\"'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.translationKeyFormat','null'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.translationMethod','\"site\"'),('fields.745cf2fc-6457-41df-a21e-131f47a52823.type','\"craft\\\\fields\\\\Matrix\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.columnSuffix','\"bkoedaxb\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.contentColumnType','\"text\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.fieldGroup','\"89833881-16ce-4ec4-abfd-1f352dc99fd8\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.handle','\"navigationItems\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.instructions','null'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.name','\"Navigation Items\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.searchable','false'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.addRowLabel','\"Add a row\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.0.0','\"col1\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.0.1.__assoc__.0.0','\"heading\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.0.1.__assoc__.0.1','\"Title\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.0.1.__assoc__.1.0','\"handle\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.0.1.__assoc__.1.1','\"title\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.0.1.__assoc__.2.0','\"width\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.0.1.__assoc__.2.1','\"\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.0.1.__assoc__.3.0','\"type\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.0.1.__assoc__.3.1','\"singleline\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.1.0','\"col2\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.1.1.__assoc__.0.0','\"heading\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.1.1.__assoc__.0.1','\"Path\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.1.1.__assoc__.1.0','\"handle\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.1.1.__assoc__.1.1','\"path\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.1.1.__assoc__.2.0','\"width\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.1.1.__assoc__.2.1','\"\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.1.1.__assoc__.3.0','\"type\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columns.__assoc__.1.1.__assoc__.3.1','\"url\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.columnType','\"text\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.defaults.0.__assoc__.0.0','\"col1\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.defaults.0.__assoc__.0.1','\"\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.defaults.0.__assoc__.1.0','\"col2\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.defaults.0.__assoc__.1.1','\"\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.maxRows','null'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.settings.minRows','null'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.translationKeyFormat','null'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.translationMethod','\"none\"'),('fields.91458f3d-5347-4b47-a507-b691e9a17943.type','\"craft\\\\fields\\\\Table\"'),('fs.uploads.hasUrls','true'),('fs.uploads.name','\"Uploads\"'),('fs.uploads.settings.path','\"@webroot/uploads\"'),('fs.uploads.type','\"craft\\\\fs\\\\Local\"'),('fs.uploads.url','\"@web/uploads\"'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elementCondition','null'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.elementCondition','null'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.fieldUid','\"91458f3d-5347-4b47-a507-b691e9a17943\"'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.instructions','null'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.label','null'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.required','false'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.tip','null'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.uid','\"686ffd67-369d-46ed-b41a-92ebacedf32f\"'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.userCondition','null'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.warning','null'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.elements.0.width','100'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.name','\"Navigation\"'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.uid','\"328f8abf-19f4-44cb-bc68-65381792c18f\"'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.fieldLayouts.9d72560f-07d2-42ea-87b5-62c13b9aa05b.tabs.0.userCondition','null'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.handle','\"primaryNavigation\"'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.name','\"Primary Navigation\"'),('globalSets.8321f181-1adc-441d-9199-5af52c1c14a4.sortOrder','2'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.field','\"745cf2fc-6457-41df-a21e-131f47a52823\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elementCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.fieldUid','\"95ecac41-0668-4b7c-a8ac-8ec14d07b5af\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.label','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.required','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.tip','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.uid','\"396067c7-0eca-458e-b983-f44a9df6daf8\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.warning','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.0.width','100'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.elementCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.fieldUid','\"fe4b113d-bf1c-4f36-806f-80cb15f3cac8\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.label','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.required','true'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.tip','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.uid','\"dfe609b6-1246-47a6-ba40-e82290f5ba75\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.userCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.warning','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.1.width','100'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.elementCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.fieldUid','\"114dbb25-d74a-43df-9136-bbc8e4bdeaec\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.instructions','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.label','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.required','true'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.tip','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.uid','\"529cd31b-fe7e-45c6-8833-985ad227c53e\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.userCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.warning','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.2.width','100'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.elementCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.fieldUid','\"36e3ae0f-08a5-4193-af58-4ed32c350d94\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.instructions','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.label','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.required','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.tip','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.uid','\"0ea3fdb0-2b83-4152-ad0d-47dd579771b9\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.userCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.warning','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.3.width','100'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.elementCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.fieldUid','\"4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.instructions','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.label','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.required','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.tip','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.uid','\"71715eeb-b5f3-48ec-9aaa-435f18525e06\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.userCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.warning','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.4.width','100'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.elementCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.fieldUid','\"e58e1829-76c2-476c-bf92-2f56e2f3900e\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.instructions','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.label','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.required','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.tip','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.uid','\"581dde12-0661-476b-adbd-8015ea94a58e\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.userCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.warning','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.elements.5.width','100'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.name','\"Content\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.uid','\"00f73aed-2f65-4a99-852b-a103a01c4031\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fieldLayouts.09f77758-0e87-4658-8750-d44df13f6a10.tabs.0.userCondition','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.columnSuffix','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.contentColumnType','\"text\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.fieldGroup','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.handle','\"panelContent\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.instructions','\"Content\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.name','\"Content\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.searchable','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.availableTransforms','\"\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.availableVolumes','\"\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.columnType','\"text\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.configSelectionMode','\"choose\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.defaultTransform','\"\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.manualConfig','\"\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.purifierConfig','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.purifyHtml','true'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.redactorConfig','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.removeEmptyTags','true'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.removeInlineStyles','true'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.removeNbsp','true'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.showHtmlButtonForNonAdmins','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.showUnpermittedFiles','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.settings.uiMode','\"enlarged\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.translationKeyFormat','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.translationMethod','\"none\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.114dbb25-d74a-43df-9136-bbc8e4bdeaec.type','\"craft\\\\redactor\\\\Field\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.columnSuffix','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.contentColumnType','\"string\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.fieldGroup','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.handle','\"image\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.instructions','\"Image\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.name','\"Image\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.searchable','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.allowedKinds','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.allowSelfRelations','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.allowSubfolders','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.allowUploads','true'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.branchLimit','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.defaultUploadLocationSource','\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.defaultUploadLocationSubpath','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.localizeRelations','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.maintainHierarchy','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.maxRelations','1'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.minRelations','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.previewMode','\"full\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.restrictedDefaultUploadSubpath','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.restrictedLocationSource','\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.restrictedLocationSubpath','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.restrictFiles','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.restrictLocation','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.selectionCondition.__assoc__.1.1','\"global\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.selectionCondition.__assoc__.2.0','\"class\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.selectionLabel','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.showSiteMenu','true'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.showUnpermittedFiles','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.sources','\"*\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.targetSiteId','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.validateRelatedElements','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.settings.viewMode','\"list\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.translationKeyFormat','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.translationMethod','\"site\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.36e3ae0f-08a5-4193-af58-4ed32c350d94.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.columnSuffix','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.contentColumnType','\"text\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.fieldGroup','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.handle','\"heroButtonText\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.instructions','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.name','\"Button Text\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.searchable','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.settings.byteLimit','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.settings.charLimit','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.settings.code','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.settings.columnType','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.settings.initialRows','4'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.settings.multiline','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.settings.placeholder','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.settings.uiMode','\"normal\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.translationKeyFormat','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.translationMethod','\"none\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.columnSuffix','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.contentColumnType','\"string(256)\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.fieldGroup','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.handle','\"subject\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.instructions','\"Subject\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.name','\"Subject\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.searchable','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.settings.byteLimit','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.settings.charLimit','64'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.settings.code','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.settings.columnType','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.settings.initialRows','4'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.settings.multiline','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.settings.placeholder','\"Subject\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.settings.uiMode','\"normal\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.translationKeyFormat','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.translationMethod','\"none\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.95ecac41-0668-4b7c-a8ac-8ec14d07b5af.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.columnSuffix','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.contentColumnType','\"text\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.fieldGroup','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.handle','\"heroButtonHref\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.instructions','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.name','\"Button Link\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.searchable','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.settings.byteLimit','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.settings.charLimit','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.settings.code','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.settings.columnType','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.settings.initialRows','4'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.settings.multiline','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.settings.placeholder','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.settings.uiMode','\"normal\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.translationKeyFormat','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.translationMethod','\"none\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.e58e1829-76c2-476c-bf92-2f56e2f3900e.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.columnSuffix','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.contentColumnType','\"string(256)\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.fieldGroup','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.handle','\"panelTitle\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.instructions','\"Title\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.name','\"Title\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.searchable','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.settings.byteLimit','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.settings.charLimit','64'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.settings.code','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.settings.columnType','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.settings.initialRows','4'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.settings.multiline','false'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.settings.placeholder','\"Title\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.settings.uiMode','\"normal\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.translationKeyFormat','null'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.translationMethod','\"none\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.fields.fe4b113d-bf1c-4f36-806f-80cb15f3cac8.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.handle','\"heroPanelDark\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.name','\"Hero Panel (Dark)\"'),('matrixBlockTypes.0d3d2425-6d71-474f-9ff8-bbaa45b837c5.sortOrder','2'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.field','\"745cf2fc-6457-41df-a21e-131f47a52823\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elementCondition','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.fieldUid','\"79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.label','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.required','false'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.tip','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.uid','\"2135836d-280a-40a2-8639-bd0cf29c70c9\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.warning','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.0.width','100'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.elementCondition','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.fieldUid','\"1da30993-295b-40b9-aab0-24e5a9812929\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.label','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.required','false'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.tip','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.uid','\"85e4d323-90fe-4f06-8e83-6bb8a14dbe52\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.userCondition','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.warning','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.elements.1.width','100'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.name','\"Content\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.uid','\"4f5030ff-d953-4be0-aba7-8d3a83b83a1a\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fieldLayouts.305b4a3d-50b4-48a2-84f2-7cf8c8e24a4d.tabs.0.userCondition','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.columnSuffix','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.contentColumnType','\"text\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.fieldGroup','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.handle','\"panelSubheading\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.instructions','\"Panel Subheading\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.name','\"Panel Subheading\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.searchable','false'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.settings.byteLimit','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.settings.charLimit','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.settings.code','false'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.settings.columnType','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.settings.initialRows','4'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.settings.multiline','false'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.settings.placeholder','\"Panel Subheading\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.settings.uiMode','\"enlarged\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.translationKeyFormat','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.translationMethod','\"none\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.1da30993-295b-40b9-aab0-24e5a9812929.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.columnSuffix','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.contentColumnType','\"string(512)\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.fieldGroup','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.handle','\"panelTitle\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.instructions','\"Panel Title\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.name','\"Panel Title\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.searchable','false'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.settings.byteLimit','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.settings.charLimit','128'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.settings.code','false'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.settings.columnType','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.settings.initialRows','4'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.settings.multiline','false'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.settings.placeholder','\"Panel Title\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.settings.uiMode','\"normal\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.translationKeyFormat','null'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.translationMethod','\"none\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.fields.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.handle','\"contentPanel\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.name','\"Content Panel\"'),('matrixBlockTypes.220d125c-af88-4a55-9b6c-ddae8a634855.sortOrder','3'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.field','\"745cf2fc-6457-41df-a21e-131f47a52823\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elementCondition','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.fieldUid','\"5bb2582c-1b3b-4a0a-b234-64558f60c9a9\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.label','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.required','true'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.tip','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.uid','\"dd751407-aa30-4745-b0a5-72d422753bde\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.warning','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.elements.0.width','100'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.name','\"Content\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.uid','\"2ac12cc5-ad94-48a7-849b-67ac92f395b2\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fieldLayouts.846e10fa-cb8e-498b-ada3-fdd0b84bc91c.tabs.0.userCondition','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.columnSuffix','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.contentColumnType','\"string\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.fieldGroup','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.handle','\"image\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.instructions','\"Add image\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.name','\"Image\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.searchable','false'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.allowedKinds','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.allowSelfRelations','false'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.allowSubfolders','false'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.allowUploads','true'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.branchLimit','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.defaultUploadLocationSource','\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.defaultUploadLocationSubpath','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.localizeRelations','false'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.maintainHierarchy','false'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.maxRelations','1'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.minRelations','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.previewMode','\"full\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.restrictedDefaultUploadSubpath','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.restrictedLocationSource','\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.restrictedLocationSubpath','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.restrictFiles','false'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.restrictLocation','false'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.selectionCondition.__assoc__.1.1','\"global\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.selectionCondition.__assoc__.2.0','\"class\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.selectionLabel','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.showSiteMenu','true'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.showUnpermittedFiles','false'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.sources','\"*\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.targetSiteId','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.validateRelatedElements','false'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.settings.viewMode','\"list\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.translationKeyFormat','null'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.translationMethod','\"site\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.fields.5bb2582c-1b3b-4a0a-b234-64558f60c9a9.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.handle','\"imagePanel\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.name','\"Image panel\"'),('matrixBlockTypes.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6.sortOrder','4'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.field','\"745cf2fc-6457-41df-a21e-131f47a52823\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elementCondition','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.fieldUid','\"0d01ac2a-6f7f-4925-8c97-10d917e18c84\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.label','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.required','true'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.tip','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.uid','\"965e5b68-9fb4-420f-b6be-7bf75d5d16ff\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.warning','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.0.width','100'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.elementCondition','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.fieldUid','\"6dc1ef68-7606-4254-8f3e-ab00a4a0b146\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.label','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.required','true'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.tip','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.uid','\"0af1f30c-23c0-412d-8cd9-56043147e74e\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.userCondition','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.warning','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.1.width','100'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.elementCondition','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.fieldUid','\"0afdac73-846a-4985-a071-851fed756ca9\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.instructions','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.label','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.required','true'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.tip','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.uid','\"548b0e08-7744-4dd9-be93-431f94f05c9e\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.userCondition','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.warning','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.elements.2.width','100'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.name','\"Content\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.uid','\"9106d75e-ab2e-4394-989c-e5865e75ee12\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fieldLayouts.67b3defe-82e7-4613-9aa0-0a6c02bc0b02.tabs.0.userCondition','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.columnSuffix','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.contentColumnType','\"string(256)\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.fieldGroup','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.handle','\"buttonText\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.instructions','\"Button Text\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.name','\"Button Text\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.searchable','false'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.settings.byteLimit','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.settings.charLimit','64'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.settings.code','false'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.settings.columnType','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.settings.initialRows','4'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.settings.multiline','false'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.settings.placeholder','\"Button Text\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.settings.uiMode','\"normal\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.translationKeyFormat','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.translationMethod','\"none\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0afdac73-846a-4985-a071-851fed756ca9.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.columnSuffix','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.contentColumnType','\"string(512)\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.fieldGroup','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.handle','\"panelTitle\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.instructions','\"Title\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.name','\"Title\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.searchable','false'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.settings.byteLimit','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.settings.charLimit','128'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.settings.code','false'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.settings.columnType','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.settings.initialRows','4'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.settings.multiline','false'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.settings.placeholder','\"Title\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.settings.uiMode','\"normal\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.translationKeyFormat','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.translationMethod','\"none\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.0d01ac2a-6f7f-4925-8c97-10d917e18c84.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.columnSuffix','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.contentColumnType','\"string(255)\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.fieldGroup','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.handle','\"buttonHref\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.instructions','\"Button Link\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.name','\"Button Link\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.searchable','false'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.settings.maxLength','255'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.settings.types.0','\"url\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.translationKeyFormat','null'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.translationMethod','\"none\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.fields.6dc1ef68-7606-4254-8f3e-ab00a4a0b146.type','\"craft\\\\fields\\\\Url\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.handle','\"callToAction\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.name','\"Call To Action Panel\"'),('matrixBlockTypes.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e.sortOrder','5'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.field','\"745cf2fc-6457-41df-a21e-131f47a52823\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elementCondition','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.fieldUid','\"5e672526-c38e-4fdc-b248-363c3c83ef20\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.label','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.required','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.tip','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.uid','\"f95608b1-f109-480b-879f-dd5b14c87e42\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.warning','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.0.width','100'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.elementCondition','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.fieldUid','\"9d42013b-11c6-42cf-b45b-fa037c8bcaba\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.label','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.required','true'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.tip','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.uid','\"b40f3b0d-7728-400a-a981-73e951a9df58\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.userCondition','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.warning','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.1.width','100'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.elementCondition','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.fieldUid','\"de802f05-8a3d-4fbd-99ee-3188ab50874c\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.instructions','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.label','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.required','true'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.tip','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.uid','\"7d62808f-9bdc-4dbc-a381-93efed6570fa\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.userCondition','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.warning','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.2.width','100'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.elementCondition','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.fieldUid','\"ce352345-5dc4-4b53-a997-af7ff50bf606\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.instructions','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.label','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.required','true'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.tip','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.uid','\"57d2a439-5ee2-4ace-a33f-be0f69c7716d\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.userCondition','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.warning','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.elements.3.width','100'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.name','\"Content\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.uid','\"027dd33a-c8fb-403b-abf0-04290cd0356f\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fieldLayouts.21c9356a-52c7-44c1-9232-60d247a5b475.tabs.0.userCondition','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.columnSuffix','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.contentColumnType','\"string(256)\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.fieldGroup','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.handle','\"subject\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.instructions','\"Subject\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.name','\"Subject\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.searchable','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.settings.byteLimit','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.settings.charLimit','64'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.settings.code','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.settings.columnType','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.settings.initialRows','4'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.settings.multiline','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.settings.placeholder','\"Subject\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.settings.uiMode','\"normal\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.translationKeyFormat','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.translationMethod','\"none\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.5e672526-c38e-4fdc-b248-363c3c83ef20.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.columnSuffix','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.contentColumnType','\"string(1024)\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.fieldGroup','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.handle','\"panelTitle\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.instructions','\"Title\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.name','\"Title\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.searchable','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.settings.byteLimit','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.settings.charLimit','256'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.settings.code','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.settings.columnType','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.settings.initialRows','4'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.settings.multiline','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.settings.placeholder','\"Title\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.settings.uiMode','\"normal\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.translationKeyFormat','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.translationMethod','\"none\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.9d42013b-11c6-42cf-b45b-fa037c8bcaba.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.columnSuffix','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.contentColumnType','\"string\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.fieldGroup','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.handle','\"image\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.instructions','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.name','\"Image\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.searchable','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.allowedKinds','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.allowSelfRelations','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.allowSubfolders','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.allowUploads','true'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.branchLimit','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.defaultUploadLocationSource','\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.defaultUploadLocationSubpath','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.localizeRelations','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.maintainHierarchy','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.maxRelations','1'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.minRelations','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.previewMode','\"full\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.restrictedDefaultUploadSubpath','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.restrictedLocationSource','\"volume:9cfc771b-b401-4434-bbd3-e0e94c877314\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.restrictedLocationSubpath','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.restrictFiles','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.restrictLocation','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.selectionCondition.__assoc__.1.1','\"global\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.selectionCondition.__assoc__.2.0','\"class\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.selectionLabel','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.showSiteMenu','true'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.showUnpermittedFiles','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.sources','\"*\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.targetSiteId','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.validateRelatedElements','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.settings.viewMode','\"list\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.translationKeyFormat','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.translationMethod','\"site\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.ce352345-5dc4-4b53-a997-af7ff50bf606.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.columnSuffix','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.contentColumnType','\"text\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.fieldGroup','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.handle','\"panelContent\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.instructions','\"Content\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.name','\"Content\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.searchable','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.availableTransforms','\"\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.availableVolumes','\"\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.columnType','\"text\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.configSelectionMode','\"choose\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.defaultTransform','\"\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.manualConfig','\"\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.purifierConfig','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.purifyHtml','true'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.redactorConfig','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.removeEmptyTags','true'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.removeInlineStyles','true'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.removeNbsp','true'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.showHtmlButtonForNonAdmins','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.showUnpermittedFiles','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.settings.uiMode','\"enlarged\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.translationKeyFormat','null'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.translationMethod','\"none\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.fields.de802f05-8a3d-4fbd-99ee-3188ab50874c.type','\"craft\\\\redactor\\\\Field\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.handle','\"heroPanel\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.name','\"Hero Panel\"'),('matrixBlockTypes.c84251ed-c157-4470-8a0b-fa532933274f.sortOrder','1'),('meta.__names__.09cde05d-5606-478a-8ab0-d9a6a607d414','\"Contact\"'),('meta.__names__.0afdac73-846a-4985-a071-851fed756ca9','\"Button Text\"'),('meta.__names__.0b9c054a-9bbd-4547-b554-70bfd7142228','\"Waterloo Innovation Park\"'),('meta.__names__.0d01ac2a-6f7f-4925-8c97-10d917e18c84','\"Title\"'),('meta.__names__.0d3d2425-6d71-474f-9ff8-bbaa45b837c5','\"Hero Panel (Dark)\"'),('meta.__names__.114dbb25-d74a-43df-9136-bbc8e4bdeaec','\"Content\"'),('meta.__names__.1da30993-295b-40b9-aab0-24e5a9812929','\"Panel Subheading\"'),('meta.__names__.220d125c-af88-4a55-9b6c-ddae8a634855','\"Content Panel\"'),('meta.__names__.36e3ae0f-08a5-4193-af58-4ed32c350d94','\"Image\"'),('meta.__names__.402b359e-759c-4938-b279-b9a22b2c6d6a','\"Waterloo Innovation Park\"'),('meta.__names__.42a3ddcd-d834-49a3-a79e-21c3f11a6ab6','\"Image panel\"'),('meta.__names__.4bf1c6a2-b8b6-48fb-bdac-d9e5804d9ab6','\"Button Text\"'),('meta.__names__.5bb2582c-1b3b-4a0a-b234-64558f60c9a9','\"Image\"'),('meta.__names__.5e672526-c38e-4fdc-b248-363c3c83ef20','\"Subject\"'),('meta.__names__.687cd2f1-06f5-4174-ab03-40daaa93ad90','\"Panel Title\"'),('meta.__names__.6dc1ef68-7606-4254-8f3e-ab00a4a0b146','\"Button Link\"'),('meta.__names__.745cf2fc-6457-41df-a21e-131f47a52823','\"Content\"'),('meta.__names__.78ee6ec1-b0de-4912-a9f9-ced7e4c1646e','\"Call To Action Panel\"'),('meta.__names__.79e72fa5-51bb-408b-b0b7-ebd8acbbe7b2','\"Panel Title\"'),('meta.__names__.8321f181-1adc-441d-9199-5af52c1c14a4','\"Primary Navigation\"'),('meta.__names__.89833881-16ce-4ec4-abfd-1f352dc99fd8','\"Common\"'),('meta.__names__.8c1501f8-32b3-4150-91bc-23f988eb98e5','\"About\"'),('meta.__names__.91458f3d-5347-4b47-a507-b691e9a17943','\"Navigation Items\"'),('meta.__names__.95ecac41-0668-4b7c-a8ac-8ec14d07b5af','\"Subject\"'),('meta.__names__.9cfc771b-b401-4434-bbd3-e0e94c877314','\"Uploads\"'),('meta.__names__.9d42013b-11c6-42cf-b45b-fa037c8bcaba','\"Title\"'),('meta.__names__.c21e6094-c48b-4da7-b900-dd593e0d4125','\"Contact\"'),('meta.__names__.c84251ed-c157-4470-8a0b-fa532933274f','\"Hero Panel\"'),('meta.__names__.ce352345-5dc4-4b53-a997-af7ff50bf606','\"Image\"'),('meta.__names__.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c','\"Home\"'),('meta.__names__.de802f05-8a3d-4fbd-99ee-3188ab50874c','\"Content\"'),('meta.__names__.e58e1829-76c2-476c-bf92-2f56e2f3900e','\"Button Link\"'),('meta.__names__.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5','\"About\"'),('meta.__names__.fd107921-d306-448f-ad1a-e7c2ef60913c','\"Home\"'),('meta.__names__.fe4b113d-bf1c-4f36-806f-80cb15f3cac8','\"Title\"'),('plugins.contact-form.edition','\"standard\"'),('plugins.contact-form.enabled','true'),('plugins.contact-form.schemaVersion','\"1.0.0\"'),('plugins.redactor.edition','\"standard\"'),('plugins.redactor.enabled','true'),('plugins.redactor.schemaVersion','\"2.3.0\"'),('plugins.seo.edition','\"standard\"'),('plugins.seo.enabled','true'),('plugins.seo.schemaVersion','\"3.2.0\"'),('sections.c21e6094-c48b-4da7-b900-dd593e0d4125.defaultPlacement','\"end\"'),('sections.c21e6094-c48b-4da7-b900-dd593e0d4125.enableVersioning','true'),('sections.c21e6094-c48b-4da7-b900-dd593e0d4125.handle','\"contact\"'),('sections.c21e6094-c48b-4da7-b900-dd593e0d4125.name','\"Contact\"'),('sections.c21e6094-c48b-4da7-b900-dd593e0d4125.propagationMethod','\"all\"'),('sections.c21e6094-c48b-4da7-b900-dd593e0d4125.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.enabledByDefault','true'),('sections.c21e6094-c48b-4da7-b900-dd593e0d4125.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.hasUrls','true'),('sections.c21e6094-c48b-4da7-b900-dd593e0d4125.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.template','\"_pages/interior_contact.twig\"'),('sections.c21e6094-c48b-4da7-b900-dd593e0d4125.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.uriFormat','\"contact\"'),('sections.c21e6094-c48b-4da7-b900-dd593e0d4125.type','\"single\"'),('sections.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c.defaultPlacement','\"end\"'),('sections.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c.enableVersioning','true'),('sections.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c.handle','\"home\"'),('sections.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c.name','\"Home\"'),('sections.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c.propagationMethod','\"all\"'),('sections.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.enabledByDefault','true'),('sections.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.hasUrls','true'),('sections.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.template','\"index\"'),('sections.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.uriFormat','\"__home__\"'),('sections.d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c.type','\"single\"'),('sections.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5.defaultPlacement','\"end\"'),('sections.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5.enableVersioning','true'),('sections.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5.handle','\"about\"'),('sections.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5.name','\"About\"'),('sections.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5.propagationMethod','\"all\"'),('sections.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.enabledByDefault','true'),('sections.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.hasUrls','true'),('sections.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.template','\"_pages/interior_about.twig\"'),('sections.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5.siteSettings.402b359e-759c-4938-b279-b9a22b2c6d6a.uriFormat','\"about\"'),('sections.ee51cfa4-ec13-4103-bf30-68e7c1b63ac5.type','\"single\"'),('siteGroups.0b9c054a-9bbd-4547-b554-70bfd7142228.name','\"Waterloo Innovation Park\"'),('sites.402b359e-759c-4938-b279-b9a22b2c6d6a.baseUrl','\"@web\"'),('sites.402b359e-759c-4938-b279-b9a22b2c6d6a.enabled','true'),('sites.402b359e-759c-4938-b279-b9a22b2c6d6a.handle','\"default\"'),('sites.402b359e-759c-4938-b279-b9a22b2c6d6a.hasUrls','true'),('sites.402b359e-759c-4938-b279-b9a22b2c6d6a.language','\"en-US\"'),('sites.402b359e-759c-4938-b279-b9a22b2c6d6a.name','\"Waterloo Innovation Park\"'),('sites.402b359e-759c-4938-b279-b9a22b2c6d6a.primary','true'),('sites.402b359e-759c-4938-b279-b9a22b2c6d6a.siteGroup','\"0b9c054a-9bbd-4547-b554-70bfd7142228\"'),('sites.402b359e-759c-4938-b279-b9a22b2c6d6a.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Waterloo Innovation Park\"'),('system.schemaVersion','\"4.4.0.4\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elementCondition','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.autocapitalize','true'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.autocomplete','false'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.autocorrect','true'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.class','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.disabled','false'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.elementCondition','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.id','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.instructions','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.label','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.max','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.min','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.name','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.orientation','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.placeholder','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.readonly','false'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.requirable','false'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.size','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.step','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.tip','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.title','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.uid','\"dca2f5cd-1a06-4bd0-94bf-7f620a3fea5d\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.userCondition','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.warning','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.0.width','100'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.attribute','\"alt\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.class','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.cols','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.disabled','false'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.elementCondition','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.id','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.instructions','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.label','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.name','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.orientation','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.placeholder','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.readonly','false'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.requirable','true'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.required','false'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.rows','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.tip','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.title','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.uid','\"5e4bda1a-14ad-45e9-acbf-7cf61cbe4c36\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.userCondition','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.warning','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.elements.1.width','100'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.name','\"Content\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.uid','\"e8091142-5b46-4e2a-86ac-1e10416d5671\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fieldLayouts.955f302c-0132-4014-8378-b2ed1caaf11f.tabs.0.userCondition','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.fs','\"uploads\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.handle','\"uploads\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.name','\"Uploads\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.sortOrder','1'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.titleTranslationKeyFormat','null'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.titleTranslationMethod','\"site\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.transformFs','\"\"'),('volumes.9cfc771b-b401-4434-bbd3-e0e94c877314.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (3,14,51,NULL,50,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','656053eb-202b-4a00-a870-84a31b3fc7d1'),(4,5,53,NULL,50,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','c52335cd-44cf-490f-9b42-04b6975634fa'),(5,14,55,NULL,50,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','f8d86b09-cdbd-4c1a-9c25-8c9c4cee98c6'),(6,5,57,NULL,50,1,'2023-03-13 11:20:13','2023-03-13 11:20:13','63ce8954-f230-48fb-9e01-a1d007b94ff6');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,2,1,2,NULL),(3,2,1,3,NULL),(4,2,1,4,NULL),(5,9,1,1,NULL),(6,9,1,2,NULL),(7,9,1,3,NULL),(8,13,1,1,NULL),(9,13,1,2,NULL),(10,9,1,4,NULL),(11,9,1,5,NULL),(12,2,1,5,NULL),(13,9,1,6,NULL),(14,2,1,6,'Applied “Draft 1”'),(15,51,1,1,NULL),(16,52,1,1,NULL),(17,53,1,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' corey james keller gmail com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'slug',0,1,' home '),(2,'title',0,1,' home '),(7,'slug',0,1,''),(8,'slug',0,1,''),(9,'slug',0,1,' about '),(9,'title',0,1,' about '),(13,'slug',0,1,' contact '),(13,'title',0,1,' contact '),(41,'alt',0,1,''),(41,'extension',0,1,' webp '),(41,'filename',0,1,' asset640ef77e8c76c2 37057844 webp '),(41,'kind',0,1,' image '),(41,'slug',0,1,''),(41,'title',0,1,' placeholder '),(46,'alt',0,1,''),(46,'extension',0,1,' webp '),(46,'filename',0,1,' placeholder webp '),(46,'kind',0,1,' image '),(46,'slug',0,1,''),(46,'title',0,1,' placeholder '),(47,'alt',0,1,''),(47,'extension',0,1,' webp '),(47,'filename',0,1,' placeholder 2023 03 13 111531 ufkd webp '),(47,'kind',0,1,' image '),(47,'slug',0,1,''),(47,'title',0,1,' placeholder '),(50,'alt',0,1,''),(50,'extension',0,1,' webp '),(50,'filename',0,1,' placeholder webp '),(50,'kind',0,1,' image '),(50,'slug',0,1,''),(50,'title',0,1,' placeholder '),(51,'slug',0,1,''),(52,'slug',0,1,''),(53,'slug',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Home','home','single',1,'all','end',NULL,'2023-03-13 03:54:54','2023-03-13 03:54:54',NULL,'d8a9784a-a8a3-4e31-9bf5-73aa7bd6f67c'),(2,NULL,'About','about','single',1,'all','end',NULL,'2023-03-13 09:14:13','2023-03-13 09:16:41',NULL,'ee51cfa4-ec13-4103-bf30-68e7c1b63ac5'),(7,NULL,'Contact','contact','single',1,'all','end',NULL,'2023-03-13 09:17:00','2023-03-13 09:17:00',NULL,'c21e6094-c48b-4da7-b900-dd593e0d4125');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','index',1,'2023-03-13 03:54:54','2023-03-13 03:54:54','c51854c2-297a-4242-a0c2-0aa8ec4e11a0'),(2,2,1,1,'about','_pages/interior_about.twig',1,'2023-03-13 09:14:13','2023-03-13 09:17:22','2a89d2c9-9f0a-490c-959e-cea4f89e0ad8'),(3,7,1,1,'contact','_pages/interior_contact.twig',1,'2023-03-13 09:17:00','2023-03-13 09:17:00','7d57f48e-b607-435e-bbd8-8843acac5cf3');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `seo_redirects`
--

LOCK TABLES `seo_redirects` WRITE;
/*!40000 ALTER TABLE `seo_redirects` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `seo_redirects` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `seo_sitemap`
--

LOCK TABLES `seo_sitemap` WRITE;
/*!40000 ALTER TABLE `seo_sitemap` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `seo_sitemap` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'Waterloo Innovation Park','2023-03-12 17:05:10','2023-03-12 17:05:10',NULL,'0b9c054a-9bbd-4547-b554-70bfd7142228');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'1','Waterloo Innovation Park','default','en-US',1,'@web',1,'2023-03-12 17:05:10','2023-03-13 11:14:58',NULL,'402b359e-759c-4938-b279-b9a22b2c6d6a');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'corey.james.keller@gmail.com','$2y$13$M15wx58LDSv6YZmEwuFwmeebm1hxcNjHuObk/K0JDEBtdIdnj5v8K','2023-03-13 12:59:15',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2023-03-12 17:05:10','2023-03-12 17:05:10','2023-03-13 12:59:15');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Uploads',NULL,'2023-03-13 10:06:24','2023-03-13 10:16:26','af321fce-a9e9-46aa-947f-7b70e839e3b1'),(2,NULL,NULL,'Temporary filesystem',NULL,'2023-03-13 10:07:11','2023-03-13 10:07:11','38a3eac5-43ac-4f29-9188-05c5d64aef09'),(3,2,NULL,'user_1','user_1/','2023-03-13 10:07:11','2023-03-13 10:07:11','2ddb785d-9dad-4797-9fbd-3daacbe67915');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,11,'Uploads','uploads','uploads','','','site',NULL,1,'2023-03-13 10:06:24','2023-03-13 10:06:24',NULL,'9cfc771b-b401-4434-bbd3-e0e94c877314');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2023-03-12 17:06:35','2023-03-12 17:06:35','a22cfebc-42dd-4b88-983a-28fb8ef9750b'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2023-03-12 17:06:35','2023-03-12 17:06:35','8b9a496b-2731-462c-b32e-e081352a65f5'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2023-03-12 17:06:35','2023-03-12 17:06:35','c42e58dc-e9d5-4dba-ac10-b0a4751f578a'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2023-03-12 17:06:35','2023-03-12 17:06:35','edffd3b7-80c6-4dd8-80ed-802f7d48b22f');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-13 13:29:12
